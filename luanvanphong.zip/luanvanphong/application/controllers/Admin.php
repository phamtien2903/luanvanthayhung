<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Admin extends CI_Controller {

	
	public function test()
	{
		$this->load->model('MAdmin');
		$sach = $this->MAdmin->tatca();
		
		$Mydata = array('book'=>$sach);
		
		$this->load->view("admin/index.php",$Mydata);
	}


	public function __construct()
	{ 
		parent::__construct();
		 if($this->session->userdata('logged_in') !== TRUE)
		 {
      		redirect(base_url().'login');
      	 }

      	  if($this->session->userdata('level')==='0')
      	 	redirect(base_url());
     }

     function index()
     {
     	echo "Hi";
     }
}
?>