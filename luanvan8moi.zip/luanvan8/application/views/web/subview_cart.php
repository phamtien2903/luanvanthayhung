<?php
$this->load->library('cart');

?>
<div class="row">
<table  class="container">
  <thead>
    <tr>
      <th scope="col">STT</th>
      <th scope="col"> ID</th>
      <th scope="col"> TÊN SẢN PHẨM</th>
      <th scope="col">GIÁ</th>
      <th scope="col">SỐ LƯỢNG</th>
      <th scope="col">TỔNG</th>
      <th scope="col" colspan="2">-</th>
    </tr>
  </thead>
  <tbody>
<?php
$total = 0; $i=0;
foreach ($this->cart->contents() as $key => $value) {
	$i++;
	$total += $value['price']*$value['qty'];
?>
<form action="<?php echo base_url() ?>mycart/update" method="post" id="<?php echo $value['rowid'] ?>">
	<input type="hidden" name="rowid" value="<?php echo $value['rowid'] ?>">

    <tr>
      <td scope="row"><?php echo $i; ?></td>
      <td><?php echo $value['id']; ?></td>
      <td><?php echo $value['name']; ?></td>
      <td><?php echo number_format($value['price']); ?></td>
      <td>
		<input type="number" name="qty" value="<?php echo $value['qty']; ?>">
      </td>
      <td><?php echo number_format($value['price']*$value['qty']); ?> VND</td>
      <td><a href="#" onclick="return document.getElementById('<?php echo $value['rowid'] ?>').submit();">Update</a></td>
      <td>
      	<a href="<?php echo base_url() ?>mycart/del/<?php echo $value['rowid'] ?>">Delete</a>
      </td>
    </tr>
</form>
<?php
}
?>
  </tbody>
  <tfoot>
  	<tr>
  		<th colspan="5" >Tổng tiền</th>
  		<th colspan="3" ><?php
  			echo number_format($total)
  		?> VND</th>
  	</tr>
  </tfoot>
 </table>
</div>
<div align="center">
<a href="<?php echo base_url() ?>checkout.html">Thanh toán</a>

</div>