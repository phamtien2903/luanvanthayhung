<div class="container  order-md-1">
  <h2>Thông tin đặt hàng</h2>
  <p>Người mua hàng:</p>            
  <table class="table table-bordered">
   
    <tbody>
      <tr>
        <td>Email</td>
        <td><?php
        		echo $this->session->userdata('email');
         ?></td>
       
      </tr>
      <tr>
        <td>Tên</td>
        <td><?php
        		echo $this->session->userdata('name');
         ?></td>
       
      </tr>
      <tr>
        <td>Địa chỉ</td>
        <td><?php
        		echo $this->session->userdata('diachikh');
         ?></td>
      
      </tr>
       <tr>
        <td>Phone</td>
        <td><?php
        		echo $this->session->userdata('dienthoaikh');
         ?></td>
        
      </tr>
    </tbody>
  </table>
</div>

<div>
	<div class="col-md-12 order-md-1">
      <h4 class="mb-3">Billing address</h4>
      <form class="needs-validation" method="post" action="<?php echo base_url();?>mycart/finish">
        <div class="row">
          <div class="col-md-6 mb-3">
            <label for="tennguoinhan">Tên người nhận hàng</label>
            <input type="text" class="form-control" id="tennguoinhan" placeholder="" value="" name="tennguoinhan" required>
           
          </div>
          <div class="col-md-6 mb-3">
            <label for="dcnguoinhan">Địa chỉ người nhận</label>
            <input type="text" class="form-control" id="dcnguoinhan" name="dcnguoinhan" placeholder="" value="" required>
           
          </div>
        </div>

        <div class="row">
          <div class="col-md-6 mb-3">
            <label for="sdtnguoinhan">Điện thoại</label>
            <input type="text" class="form-control" id="sdtnguoinhan" name="sdtnguoinhan" placeholder="" value="" required>
           
          </div>
          <div class="col-md-6 mb-3">
            <label for="note">Ghi chú</label>
            <input type="text" class="form-control" id="note" name="note" placeholder="" value="" required>
           
          </div>
        </div>

        <hr class="mb-4">
        <button class="btn btn-primary btn-lg btn-block" type="submit">Continue to checkout</button>
      </form>
    </div>
</div>