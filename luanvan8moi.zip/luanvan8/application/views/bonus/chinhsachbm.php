<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		 <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->

		<title>Electro - HTML Ecommerce Template</title>

 		<!-- Google font -->
 		<link href="https://fonts.googleapis.com/css?family=Montserrat:400,500,700" rel="stylesheet">

 		<!-- Bootstrap -->
 		<link type="text/css" rel="stylesheet" href="<?php echo base_url(); ?>
/assets/css/bootstrap.min.css"/>

 		<!-- Slick -->
 		<link type="text/css" rel="stylesheet" href="<?php echo base_url(); ?>
/assets/css/slick.css"/>
 		<link type="text/css" rel="stylesheet" href="<?php echo base_url(); ?>
/assets/css/slick-theme.css"/>

 		<!-- nouislider -->
 		<link type="text/css" rel="stylesheet" href="<?php echo base_url(); ?>
/assets/css/nouislider.min.css"/>

 		<!-- Font Awesome Icon -->
 		<link rel="stylesheet" href="<?php echo base_url(); ?>
/assets/css/font-awesome.min.css">

 		<!-- Custom stlylesheet -->
 		<link type="text/css" rel="stylesheet" href="<?php echo base_url(); ?>
/assets/css/style.css"/>

 		<!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
 		<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
 		<!--[if lt IE 9]>
 		  <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
 		  <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
 		<![endif]-->

    </head>
	<body>
		<!-- HEADER -->
		<header>
			<!-- TOP HEADER -->
			<div id="top-header">
				<div class="container">
					<ul class="header-links pull-left">
						<li><a href="#"><i class="fa fa-phone"></i> +021-95-51-84</a></li>
						<li><a href="#"><i class="fa fa-envelope-o"></i> email@email.com</a></li>
						<li><a href="#"><i class="fa fa-map-marker"></i> 1734 Stonecoal Road</a></li>
					</ul>
					<ul class="header-links pull-right">
						<li><a href="#"><i class="fa fa-dollar"></i> USD</a></li>
						<li><a href="#"><i class="fa fa-user-o"></i> My Account</a></li>
					</ul>
				</div>
			</div>
			<!-- /TOP HEADER -->

			<!-- MAIN HEADER -->
			<div id="header">
				<!-- container -->
				<div class="container">
					<!-- row -->
					<div class="row">
						<!-- LOGO -->
						<div class="col-md-3">
							<div class="header-logo">
								<a href="#" class="logo">
									<img src="<?php echo base_url(); ?>
/assets//img/logo.png" alt="">
								</a>
							</div>
						</div>
						<!-- /LOGO -->

						<!-- SEARCH BAR -->
						<div class="col-md-6">
                  		<form method="post" action="<?php echo site_url('web/timkiem');?>">
							<div class="header-search">
								<form>
               
                                
								
									<input class="input" name="timkiem" placeholder="Nhập từ khóa cần tìm">

									<button class="search-btn" name="submit" type="submit" value="" >Search</button>
								</form>
							</div>
                        </form>
						</div>
						<!-- /SEARCH BAR -->

						<!-- ACCOUNT -->
						<div class="col-md-3 clearfix">
							<div class="header-ctn">
								<!-- Wishlist -->
								<div>
									<a href="#">
										<i class="fa fa-heart-o"></i>
										<span>Your Wishlist</span>
										<div class="qty">2</div>
									</a>
								</div>
								<!-- /Wishlist -->

								<!-- Cart -->
								<div class="dropdown">
									<a class="dropdown-toggle" data-toggle="dropdown" aria-expanded="true">
										<i class="fa fa-shopping-cart"></i>
										<span>Your Cart</span>
										<div class="qty">3</div>
									</a>
									<div class="cart-dropdown">
										<div class="cart-list">
											<div class="product-widget">
												<div class="product-img">
													<img src="<?php echo base_url(); ?>
/assets//img/product01.png" alt="">
												</div>
												<div class="product-body">
													<h3 class="product-name"><a href="#">product name goes here</a></h3>
													<h4 class="product-price"><span class="qty">1x</span>$980.00</h4>
												</div>
												<button class="delete"><i class="fa fa-close"></i></button>
											</div>

											<div class="product-widget">
												<div class="product-img">
													<img src="<?php echo base_url(); ?>
/assets//img/product02.png" alt="">
												</div>
												<div class="product-body">
													<h3 class="product-name"><a href="#">product name goes here</a></h3>
													<h4 class="product-price"><span class="qty">3x</span>$980.00</h4>
												</div>
												<button class="delete"><i class="fa fa-close"></i></button>
											</div>
										</div>
										<div class="cart-summary">
											<small>3 Item(s) selected</small>
											<h5>SUBTOTAL: $2940.00</h5>
										</div>
										<div class="cart-btns">
											<a href="#">View Cart</a>
											<a href="#">Checkout  <i class="fa fa-arrow-circle-right"></i></a>
										</div>
									</div>
								</div>
								<!-- /Cart -->

								<!-- Menu Toogle -->
								<div class="menu-toggle">
									<a href="#">
										<i class="fa fa-bars"></i>
										<span>Menu</span>
									</a>
								</div>
								<!-- /Menu Toogle -->
							</div>
						</div>
						<!-- /ACCOUNT -->
					</div>
					<!-- row -->
				</div>
				<!-- container -->
			</div>
			<!-- /MAIN HEADER -->
		</header>
		<!-- /HEADER -->

		<!-- NAVIGATION -->
		<nav id="navigation">
			<!-- container -->
			<div class="container">
				<!-- responsive-nav -->
				<div id="responsive-nav">
					<!-- NAV -->
					<ul class="main-nav nav navbar-nav">
						<li class="active"><a href="<?php echo base_url(). 'web/index' ?>">Home</a></li>
						<li><a href="<?php echo base_url(). 'web/index' ?>">Sản phẩm</a></li>
						<li><a href="<?php echo base_url(). 'web/about' ?>">Về chúng tôi</a></li>
						<li><a href="<?php echo base_url(). 'web/chinhsachbm' ?>">Chính sách bảo mật</a></li>
						<li><a href="<?php echo base_url(). 'web/dieukhoandv' ?>">Điều khoản dịch vụ</a></li>
						<li><a href="<?php echo base_url(). 'web/contact' ?>">Liên hệ</a></li>
						
					</ul>
					<!-- /NAV -->
				</div>

				<!-- /responsive-nav -->
			</div>
			<!-- /container -->
		</nav>
		
		<!-- /NAVIGATION -->

		<!-- BREADCRUMB -->
		<div id="breadcrumb" class="section">
			<!-- container -->
			<div class="container">
				<!-- row -->
				<div class="row">
					<div class="col-md-12">
						<h3 class="breadcrumb-header">Chính sách bảo mật</h3>
						<ul class="breadcrumb-tree">
							<li><u><a href="#" onclick="window.history.go(-1)">BACK</a></u></li>
							<li class="active">Chính sách bảo mật</li>
						</ul>
					</div>
				</div>
				<!-- /row -->
			</div>
			<!-- /container -->
		</div>
		<!-- /BREADCRUMB -->
		<div class="container">
			<div class="row">
				<div >
				-Để mua hàng tại Shoppt.tk, bạn có thể sẽ được yêu cầu cung cấp cho chúng tôi thông tin cá nhân (Email, Họ tên, Số ĐT liên lạc…). Mọi thông tin khai báo phải đảm bảo tính chính xác và hợp pháp. Shoppt.tk không chịu mọi trách nhiệm liên quan đến pháp luật của thông tin khai báo.
		<p><b>1.Mục đích thu thập thông tin</b></p>

		Shoppt.tk thu thập và sử dụng thông tin cá nhân bạn với mục đích sau:

		– Giao hàng và liên hệ với người mua.

		– Hỗ trợ, tư vấn về sản phẩm, dịch vụ theo yêu cầu của khách hàng.

		– Giải quyết các vấn đề khiếu nại, tranh chấp phát sinh liên quan đến việc sử dụng website Shoppt.tk.

		<p><b>2.Phạm vi thu thập thông tin :</b></p>

		Khi khách hàng mua sản phẩm tại  Shoppt.tk chúng tôi sẽ thu thập các thông tin bắt buộc sau:

		– Họ và tên.

		– Số điện thoại di động.

		– Địa chỉ email.

		Shoppt.tk không chịu mọi trách nhiệm liên quan đến pháp luật nếu thông tin khai báo của khách hàng không hợp lệ và không chính xác.

		Ngoài ra, các thông tin giao dịch gồm: lịch sử mua hàng, giá trị giao dịch, phương thức vận chuyển và thanh toán cũng được lưu trữ tại hệ thống website Shoppt.tk nhằm giải quyết những vấn đề có thể phát sinh về sau.

		<p><b>3.Thời gian lưu trữ thông tin :</b></p>

		Shoppt.tk sẽ lưu trữ thông tin của trong khoảng thời gian luật pháp quy định hoặc đến khi khách hàng đề nghị điều chỉnh sửa đổi, xóa thông tin trên hệ thống. Tuy nhiên chúng tôi sẽ lưu lại những thông tin bị thay đổi để chống các hành vi xóa dấu vết gian lận.

		<p><b>4.Lưu trữ và quản lý  thông tin cá nhân:</b></p>

		Chúng tôi lưu trữ và xử lý thông tin cá nhân của bạn tại các máy chủ đặt tại Việt Nam.
		Chúng tôi quản lý những thông tin này bằng nhiều phương tiện điện tử (máy chủ) và quy trình làm việc của đội ngũ nhân viên vận hành.

		<p><b>5.Lưu trữ và quản lý  thông tin cá nhân:</b></p>

		Bất cứ khi nào bạn sử dụng dịch vụ của chúng tôi, chúng tôi đều cung cấp cho bạn quyền truy cập và cập nhập thông tin cá nhân của mình . Ngoài ra bạn cũng có thể liên hệ với bộ phận CSKH của chúng tôi để được hỗ trợ thay đổi thông tin cá nhân của mình thông qua phương thức liên hệ trực tiếp qua bảng chat hoặc email tới địa chỉ : hotro@Shoppt.tk

		Nếu thông tin đó không đúng, chúng tôi cố gắng cung cấp cho bạn các cách để thay đổi thông tin nhanh chóng trừ khi chúng tôi phải giữ thông tin đó cho mục đích pháp lý hoặc kinh doanh hợp pháp. Khi cập nhật thông tin cá nhân của bạn, chúng tôi có thể yêu cầu bạn xác minh danh tính của mình trước khi chúng tôi xử lý yêu cầu của bạn.

		Chúng tôi cố gắng duy trì các dịch vụ của mình theo cách bảo vệ thông tin không bị phá hoại do vô tình hay cố ý. Do vậy, sau khi bạn xóa thông tin khỏi dịch vụ của chúng tôi, chúng tôi có thể không xóa ngay bản sao còn lại khỏi máy chủ đang hoạt động của mình và có thể không xóa thông tin khỏi hệ thống sao lưu của chúng tôi.

		<p><b>6.Cam kết bảo mật thông tin khách hàng :</b></p>

		Shoppt.tk cam kết sẽ bảo mật những thông tin mang tính riêng tư của bạn. Chúng tôi chỉ thu thập thông tin của bạn theo điều 2 thỏa thuận này.

		Chúng tôi khuyên quý khách rằng quý khách không nên đưa thông tin chi tiết về việc thanh toán với bất kỳ ai bằng e-mail, chúng tôi không chịu trách nhiệm về những mất mát quý khách có thể gánh chịu trong việc trao đổi thông tin của quý khách qua internet hoặc email.

		Quý khách tuyệt đối không sử dụng bất kỳ chương trình, công cụ hay hình thức nào khác để can thiệp vào hệ thống hay làm thay đổi cấu trúc dữ liệu. Nghiêm cấm việc phát tán, truyền bá hay cổ vũ cho bất kỳ hoạt động nào nhằm can thiệp, phá hoại hay xâm nhập vào dữ liệu của hệ thống website. Mọi vi phạm sẽ bị tước bỏ mọi quyền lợi cũng như sẽ bị truy tố trước pháp luật nếu cần thiết.

		Mọi thông tin giao dịch sẽ được bảo mật nhưng trong trường hợp cơ quan pháp luật yêu cầu, chúng tôi sẽ buộc phải cung cấp những thông tin này cho các cơ quan pháp luật.
		Các điều kiện, điều khoản và nội dung của trang web này được điều chỉnh bởi luật pháp Việt Nam và tòa án Việt Nam có thẩm quyền xem xét.

		<p><b>7.Thông tin khác :</b></p>

		Mọi thắc mắc, góp ý, hỏi đáp về chính sách bảo mật thông tin của Shoppt.tk , quý khách vui lòng liên hệ qua email: phamtien29030212@gmail.com hoặc Số điện thoại : 1900.633.305

						
				</div>
			</div>
		</div>
		<!-- SECTION -->
		<div class="section">
			<!-- container -->
			<div class="container">
				<!-- row -->
				<div class="row">
				</div>
				<!-- /row -->
			</div>
			<!-- /container -->
		</div>
		<!-- /SECTION -->

		<!-- NEWSLETTER -->
		<div id="newsletter" class="section">
			<!-- container -->
			<div class="container">
				<!-- row -->
				<div class="row">
					<div class="col-md-12">
						<div class="newsletter">
							<p>Sign Up for the <strong>NEWSLETTER</strong></p>
							<form>
								<input class="input" type="email" placeholder="Enter Your Email">
								<button class="newsletter-btn"><i class="fa fa-envelope"></i> Subscribe</button>
							</form>
							<ul class="newsletter-follow">
								<li>
									<a href="#"><i class="fa fa-facebook"></i></a>
								</li>
								<li>
									<a href="#"><i class="fa fa-twitter"></i></a>
								</li>
								<li>
									<a href="#"><i class="fa fa-instagram"></i></a>
								</li>
								<li>
									<a href="#"><i class="fa fa-pinterest"></i></a>
								</li>
							</ul>
						</div>
					</div>
				</div>
				<!-- /row -->
			</div>
			<!-- /container -->
		</div>
		<!-- /NEWSLETTER -->

		<!-- FOOTER -->
		<footer id="footer">
			<!-- top footer -->
			<div class="section">
				<!-- container -->
				<div class="container">
					<!-- row -->
					<div class="row">
						<div class="col-md-3 col-xs-6">
							<div class="footer">
								<h3 class="footer-title">About Us</h3>
								<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut.</p>
								<ul class="footer-links">
									<li><a href="#"><i class="fa fa-map-marker"></i>1734 Stonecoal Road</a></li>
									<li><a href="#"><i class="fa fa-phone"></i>+021-95-51-84</a></li>
									<li><a href="#"><i class="fa fa-envelope-o"></i>email@email.com</a></li>
								</ul>
							</div>
						</div>

						<div class="col-md-3 col-xs-6">
							<div class="footer">
								<h3 class="footer-title">Categories</h3>
								<ul class="footer-links">
									<li><a href="#">Hot deals</a></li>
									<li><a href="#">Laptops</a></li>
									<li><a href="#">Smartphones</a></li>
									<li><a href="#">Cameras</a></li>
									<li><a href="#">Accessories</a></li>
								</ul>
							</div>
						</div>

						<div class="clearfix visible-xs"></div>

						<div class="col-md-3 col-xs-6">
							<div class="footer">
								<h3 class="footer-title">Information</h3>
								<ul class="footer-links">
									<li><a href="#">About Us</a></li>
									<li><a href="#">Contact Us</a></li>
									<li><a href="#">Privacy Policy</a></li>
									<li><a href="#">Orders and Returns</a></li>
									<li><a href="#">Terms & Conditions</a></li>
								</ul>
							</div>
						</div>

						<div class="col-md-3 col-xs-6">
							<div class="footer">
								<h3 class="footer-title">Service</h3>
								<ul class="footer-links">
									<li><a href="#">My Account</a></li>
									<li><a href="#">View Cart</a></li>
									<li><a href="#">Wishlist</a></li>
									<li><a href="#">Track My Order</a></li>
									<li><a href="#">Help</a></li>
								</ul>
							</div>
						</div>
					</div>
					<!-- /row -->
				</div>
				<!-- /container -->
			</div>
			<!-- /top footer -->

			<!-- bottom footer -->
			<div id="bottom-footer" class="section">
				<div class="container">
					<!-- row -->
					<div class="row">
						<div class="col-md-12 text-center">
							<ul class="footer-payments">
								<li><a href="#"><i class="fa fa-cc-visa"></i></a></li>
								<li><a href="#"><i class="fa fa-credit-card"></i></a></li>
								<li><a href="#"><i class="fa fa-cc-paypal"></i></a></li>
								<li><a href="#"><i class="fa fa-cc-mastercard"></i></a></li>
								<li><a href="#"><i class="fa fa-cc-discover"></i></a></li>
								<li><a href="#"><i class="fa fa-cc-amex"></i></a></li>
							</ul>
							<span class="copyright">
								<!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
								Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved | This template is made with <i class="fa fa-heart-o" aria-hidden="true"></i> by <a href="https://colorlib.com" target="_blank">Colorlib</a>
							<!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
							</span>


						</div>
					</div>
						<!-- /row -->
				</div>
				<!-- /container -->
			</div>
			<!-- /bottom footer -->
		</footer>
		<!-- /FOOTER -->

		<!-- jQuery Plugins -->
		<script src="<?php echo base_url(); ?>
/assets/js/jquery.min.js"></script>
		<script src="<?php echo base_url(); ?>
/assets/js/bootstrap.min.js"></script>
		<script src="<?php echo base_url(); ?>
/assets/js/slick.min.js"></script>
		<script src="<?php echo base_url(); ?>
/assets/js/nouislider.min.js"></script>
		<script src="<?php echo base_url(); ?>
/assets/s/jquery.zoom.min.js"></script>
		<script src="<?php echo base_url(); ?>
/assets/js/main.js"></script>

	</body>
</html>
