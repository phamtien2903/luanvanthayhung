<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		 <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->

		<title>Electro - HTML Ecommerce Template</title>

 		<!-- Google font -->
 		<link href="https://fonts.googleapis.com/css?family=Montserrat:400,500,700" rel="stylesheet">

 		<!-- Bootstrap -->
 		<link type="text/css" rel="stylesheet" href="<?php echo base_url(); ?>
/assets/css/bootstrap.min.css"/>

 		<!-- Slick -->
 		<link type="text/css" rel="stylesheet" href="<?php echo base_url(); ?>
/assets/css/slick.css"/>
 		<link type="text/css" rel="stylesheet" href="<?php echo base_url(); ?>
/assets/css/slick-theme.css"/>

 		<!-- nouislider -->
 		<link type="text/css" rel="stylesheet" href="<?php echo base_url(); ?>
/assets/css/nouislider.min.css"/>

 		<!-- Font Awesome Icon -->
 		<link rel="stylesheet" href="<?php echo base_url(); ?>
/assets/css/font-awesome.min.css">

 		<!-- Custom stlylesheet -->
 		<link type="text/css" rel="stylesheet" href="<?php echo base_url(); ?>
/assets/css/style.css"/>

		<!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
		<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
		<!--[if lt IE 9]>
		  <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
		  <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
		<![endif]-->

    </head>
	<body>
		<!-- HEADER -->
		<header>
			<!-- TOP HEADER -->
			<div id="top-header">
				<div class="container">
				<?php
			 if($this->session->userdata('logged_in') !== TRUE)
			 	{?>
					<ul class="header-links pull-left">
						<li><a href="#"><i class="fa fa-phone"></i> 0123 113 114 </a></li>
						<li><a href="#"><i class="fa fa-envelope-o"></i> email@email.com</a></li>
						<li><a href="#"><i class="fa fa-map-marker"></i> 80 Cao Lỗ Phường 4 Q8</a></li>
					</ul>
					<ul class="header-links pull-right">
						<li><a href="<?php echo base_url()?>login/index1/"></i> Dang Ky</a></li>
						<li><a href="<?php echo base_url()?>login/index/"><i class="fa fa-user-o"></i> Dang Nhap</a></li>
					</ul>
				</div>
				<?php
				}
			else
			{
				?>
				<div class="header-links pull-right">
					<?php
					//print_r($_SESSION);
					?>
					<a href=# style="color:white">	Hi, <?php echo $this->session->userdata('name') ?></a>
					
					&nbsp;&nbsp;&nbsp;&nbsp;
						<a href="<?php echo base_url()?>login/logout" style="color:white" onclick="return confirm('Bạn có chắc chắn Đăng xuất không ?')">Đăng xuất</a>
				</div>
				<?php
			}
				?>
			</div>
			<!-- /TOP HEADER -->

			<!-- MAIN HEADER -->
			<div id="header">
				<!-- container -->
				<div class="container">
					<!-- row -->
					<div class="row">
						<!-- LOGO -->
						<div class="col-md-3">
							<div class="header-logo">
								<a href="#" class="logo">
									<img src="<?php echo base_url(); ?>
/assets/img/logo.png" alt="">
								</a>
							</div>
						</div>
						<!-- /LOGO -->

						<!-- SEARCH BAR -->
					<div class="col-md-6">
                  		<form method="post" action="<?php echo site_url('web/timkiem');?>">
							<div class="header-search">
								<form>
               
                                
								
									<input class="input" name="timkiem" placeholder="Nhập từ khóa cần tìm">

									<button class="search-btn" name="submit" type="submit" value="" >Search</button>
								</form>
							</div>
                        </form>
						</div>
						<!-- /SEARCH BAR -->

						<!-- ACCOUNT -->
						<div class="col-md-3 clearfix">
							<div class="header-ctn">
								<!-- Wishlist -->
								<div>
									
								</div>
								<!-- /Wishlist -->

								<!-- Cart -->
								<div class="dropdown">
									<a class="dropdown-toggle" data-toggle="dropdown" aria-expanded="true">
										<i class="fa fa-shopping-cart"></i>
										<span>Your Cart</span>
										<div class="qty"></div>
									</a>
									<div class="cart-dropdown">
										<div class="cart-list">
											
											<?php 

									$this->load->library('cart');
									foreach ($this->cart->contents() as $key => $value) 
											{
												?>
											<div class="product-widget">

												<div class="product-body">
													<h3 class="product-name"><a href="#"><?php echo $value['name']; ?></a></h3>
													<h4 class="product-price"><span class="qty"  ><?php echo $value['qty']; ?></span><?php echo number_format($value['price']); ?></h4>
												</div>
												<button class="delete"><i class="fa fa-close"></i></button>
											</div>
											<?php
										}
											?>
										</div>
										
										<div class="cart-btns">
											<a href="<?php echo base_url() ?>mycart/show">View Cart</a>
											<a href="<?php echo base_url() ?>Mycart/Checkout">Checkout  <i class="fa fa-arrow-circle-right"></i></a>
										</div>
									</div>
								</div>
								<!-- /Cart -->

								<!-- Menu Toogle -->
								<div class="menu-toggle">
									<a href="#">
										<i class="fa fa-bars"></i>
										<span>Menu</span>
									</a>
								</div>
								<!-- /Menu Toogle -->
							</div>
						</div>
						<!-- /ACCOUNT -->
					</div>
					<!-- row -->
				</div>
				<!-- container -->
			</div>
			<!-- /MAIN HEADER -->
		</header>
		<!-- /HEADER -->

		<!-- NAVIGATION -->
		<nav id="navigation">
			<!-- container -->
			<div class="container">
				<!-- responsive-nav -->
				<div id="responsive-nav">
					<!-- NAV -->
					<ul class="main-nav nav navbar-nav">
						
					<li class="active"><a href="<?php echo base_url(). 'web/index' ?>">Home</a></li>
									<?php 
						foreach ($menu as $key => $value) {
												
						?>
									
									<li><a  href="<?php echo base_url().'web/store/'.$value->idloaisp;?>"><?php echo $value->tenloaisp?></a></li>
									
									<?php 
						}?>
					</ul>
					<!-- /NAV -->
				</div>
				<!-- /responsive-nav -->
			</div>
			<!-- /container -->
		</nav>
		<!-- /NAVIGATION -->

		<!-- BREADCRUMB -->
		<div id="breadcrumb" class="section">
			<!-- container -->
			<div class="container">
				<!-- row -->
				<div class="row">
					<div class="col-md-12">
						<ul class="breadcrumb-tree">
							<li><u><a href="#" onclick="window.history.go(-1)">BACK</a></u></li>
							<li><a href="#"><?php echo $data1['tenloaisp'];?></a></li>
							<li class="active"><?php echo $data1['tensp'];?></li>
						</ul>
					</div>
				</div>
				<!-- /row -->
			</div>
			<!-- /container -->
		</div>
		<!-- /BREADCRUMB -->

		<!-- SECTION -->
		<div class="section">
			<!-- container -->
			<div class="container">
				<!-- row -->
				<div class="row">
					<!-- Product main img -->
					<div class="col-md-5 col-md-push-2">
						<div id="product-main-img">
							<div class="product-preview">
								<img src="<?php echo base_url()?>assets/img/sanpham/<?php echo $data1['mausp'] ?>" alt="">
							</div>

							<div class="product-preview">
								<img src="<?php echo base_url()?>assets/img/sanpham/<?php echo $data1['mausp'] ?>" alt="">
							</div>

							<div class="product-preview">
								<img src="<?php echo base_url()?>assets/img/sanpham/<?php echo $data1['mausp'] ?>" alt="">
							</div>

							<div class="product-preview">
								<img src="<?php echo base_url()?>assets/img/sanpham/<?php echo $data1['mausp'] ?>" alt="">
							</div>
						</div>
					</div>
					<!-- /Product main img -->

					<!-- Product thumb imgs -->
					<div class="col-md-2  col-md-pull-5">
						<div id="product-imgs">
							<div class="product-preview">
								<img src="<?php echo base_url()?>assets/img/sanpham/<?php echo $data1['mausp'] ?>" alt="">
							</div>

							<div class="product-preview">
								<img src="<?php echo base_url()?>assets/img/sanpham/<?php echo $data1['mausp'] ?>" alt="">
							</div>

							<div class="product-preview">
								<img src="<?php echo base_url()?>assets/img/sanpham/<?php echo $data1['mausp'] ?>" alt="">
							</div>

							<div class="product-preview">
								<img src="<?php echo base_url()?>assets/img/sanpham/<?php echo $data1['mausp'] ?>" alt="">
							</div>
						</div>
					</div>
					<!-- /Product thumb imgs -->

					<!-- Product details -->
					<?php
					$this->load->view($subview1);
					?>
                    
					<!-- /Product details -->

					<!-- Product tab -->
					<div class="col-md-12">
						<div id="product-tab">
							<!-- product tab nav -->
							<ul class="tab-nav">
							
								<li><a data-toggle="tab" href="#tab3">Reviews (3)</a></li>
							</ul>
							<!-- /product tab nav -->

							<!-- product tab content -->
							<div class="tab-content">
						

								<!-- tab3  -->
								<div id="tab3" class="tab-pane fade in">
									<div class="row">
										<!-- Rating -->
										<div class="col-md-3">
											<div id="rating">
												<div class="rating-avg">
													<span>4.5</span>
													<div class="rating-stars">
														<i class="fa fa-star"></i>
														<i class="fa fa-star"></i>
														<i class="fa fa-star"></i>
														<i class="fa fa-star"></i>
														<i class="fa fa-star-o"></i>
													</div>
												</div>
												<ul class="rating">
													<li>
														<div class="rating-stars">
															<i class="fa fa-star"></i>
															<i class="fa fa-star"></i>
															<i class="fa fa-star"></i>
															<i class="fa fa-star"></i>
															<i class="fa fa-star"></i>
														</div>
														<div class="rating-progress">
															<div style="width: 80%;"></div>
														</div>
														<span class="sum">3</span>
													</li>
													<li>
														<div class="rating-stars">
															<i class="fa fa-star"></i>
															<i class="fa fa-star"></i>
															<i class="fa fa-star"></i>
															<i class="fa fa-star"></i>
															<i class="fa fa-star-o"></i>
														</div>
														<div class="rating-progress">
															<div style="width: 60%;"></div>
														</div>
														<span class="sum">2</span>
													</li>
													<li>
														<div class="rating-stars">
															<i class="fa fa-star"></i>
															<i class="fa fa-star"></i>
															<i class="fa fa-star"></i>
															<i class="fa fa-star-o"></i>
															<i class="fa fa-star-o"></i>
														</div>
														<div class="rating-progress">
															<div></div>
														</div>
														<span class="sum">0</span>
													</li>
													<li>
														<div class="rating-stars">
															<i class="fa fa-star"></i>
															<i class="fa fa-star"></i>
															<i class="fa fa-star-o"></i>
															<i class="fa fa-star-o"></i>
															<i class="fa fa-star-o"></i>
														</div>
														<div class="rating-progress">
															<div></div>
														</div>
														<span class="sum">0</span>
													</li>
													<li>
														<div class="rating-stars">
															<i class="fa fa-star"></i>
															<i class="fa fa-star-o"></i>
															<i class="fa fa-star-o"></i>
															<i class="fa fa-star-o"></i>
															<i class="fa fa-star-o"></i>
														</div>
														<div class="rating-progress">
															<div></div>
														</div>
														<span class="sum">0</span>
													</li>
												</ul>
											</div>
										</div>
										<!-- /Rating -->

										<!-- Reviews -->
										<div class="col-md-6">
											<div id="reviews">
												<ul class="reviews">
													<?php foreach ($test as $key => $bl) {
														# code...
													?>
													<li>
														<div class="review-heading">
															<h5 class="name"><?php echo $bl['user']; ?></h5>
															<p class="date"><?php echo $bl['time']; ?></p>
															<div class="review-rating">
																<i class="fa fa-star"></i>
																<i class="fa fa-star"></i>
																<i class="fa fa-star"></i>
																<i class="fa fa-star"></i>
																<i class="fa fa-star-o empty"></i>
															</div>
															<div><a href="<?php echo base_url();?>web/deletebluan/<?php echo $bl['idbl']; ?>">Xóa</a></div>
														</div>
														<div class="review-body">
															<p><?php echo $bl['comments']; ?></p>
														</div>
													</li>
													<?php }?>
												</ul>
												<ul class="reviews-pagination">
													<p style="color:blue;font-size:25px; border: red solid 2px;"><a href=""><?php echo $this->pagination->create_links(); ?></a></p>
												</ul>
											</div>
										</div>
										<!-- /Reviews -->

										<!-- Review Form -->
										<div class="col-md-3">
											<div id="review-form">
												<form class="review-form" method="post" action="<?php echo base_url();?>web/bluan">
													<input class="input" name="user" type="text" placeholder="Your Name">
													<input class="input" name="email" type="email" placeholder="Your Email">
													
													<textarea class="input" name="comments" placeholder="Your Review"></textarea>
													<div class="input-rating">
														<span>Your Rating: </span>
														<div class="stars">
															<input id="star5" name="rating" value="5" type="radio"><label for="star5"></label>
															<input id="star4" name="rating" value="4" type="radio"><label for="star4"></label>
															<input id="star3" name="rating" value="3" type="radio"><label for="star3"></label>
															<input id="star2" name="rating" value="2" type="radio"><label for="star2"></label>
															<input id="star1" name="rating" value="1" type="radio"><label for="star1"></label>
														</div>
													</div>
													<button class="primary-btn" name="submit" type="submit" value="Save">Submit</button>
												</form>
											</div>
										</div>
										<!-- /Review Form -->
									</div>
								</div>
								<!-- /tab3  -->
							</div>
							<!-- /product tab content  -->
						</div>
					</div>
					<!-- /product tab -->
				</div>
				<!-- /row -->
			</div>
			<!-- /container -->
		</div>
		<!-- /SECTION -->

		<!-- Section -->
		<div class="section">
			<!-- container -->
			<div class="container">
				<!-- row -->
				<div class="row">

					<div class="col-md-12">
						<div class="section-title text-center">
							<h3 class="title">SẢN PHẨM CÙNG LOẠI</h3>
						</div>
					</div>

					<!-- product -->
							<?php 
								foreach ($spkhac as $key => $value) 
								{
									# code...
								
							?>		
					<div class="col-md-3 col-xs-6">
						<div class="product">
							<div class="product-img">
								<img src="<?php echo base_url(); ?>
assets/img/sanpham/<?php echo $value->mausp ?>" alt="">
								<div class="product-label">
									<span class="sale">-30%</span>
								</div>
							</div>
							<div class="product-body">
								<p class="product-category"></p>
								<h3 class="product-name"><a href="<?php echo base_url().'web/chitiet/'.$value->idsp?>"><?php echo $value->tensp?></a></h3>
								<h4 class="product-price"><?php echo $value->giasp?>	 <del class="product-old-price">$990.00</del></h4>
								<div class="product-rating">
								</div>
								<div class="product-btns">
									<button class="add-to-wishlist"><i class="fa fa-heart-o"></i><span class="tooltipp">add to wishlist</span></button>
									<button class="add-to-compare"><i class="fa fa-exchange"></i><span class="tooltipp">add to compare</span></button>
									<button class="quick-view"><i class="fa fa-eye"></i><span class="tooltipp">quick view</span></button>
								</div>
							</div>
							<div class="add-to-cart">
								<button class="add-to-cart-btn">
													<a href="#" onclick="form_<?php echo $value->idsp;?>.submit();"><i class="fa fa-shopping-cart" >add to cart</i> </a></button>
							</div>
						</div>
					</div>
					<form action="<?php echo base_url() ?>mycart/add" method="post" accept-charset="utf-8" id='form_<?php echo $value->idsp; ?>' style="float: right;">
				<input type="hidden" name="idsp" value="<?php echo $value->idsp; ?>">
				<input type="hidden" name="soluong" value="1">
				<input type="hidden" name="giasp" value="<?php echo $value->giasp; ?>">
				<input type="hidden" name="tensp" value="<?php echo $value->tensp; ?>">
			</form>
					<?php }?>
					<!-- /product -->

				

			
					<!-- /product -->

				</div>
				<!-- /row -->
			</div>
			<!-- /container -->
		</div>
		<!-- /Section -->

		<!-- NEWSLETTER -->
		<div id="newsletter" class="section">
			<!-- container -->
			<div class="container">
				<!-- row -->
				<div class="row">
					<div class="col-md-12">
						<div class="newsletter">
							<p>Bạn chưa là <strong>Thành Viên ?</strong></p>
							<form>
								<input class="input" type="email" placeholder="Enter Your Email">
								<button ><a href="<?php echo base_url()?>login/index1/">Đăng Ký</button>
							</form>
							<ul class="newsletter-follow">
								<li>
									<a href="#"><i class="fa fa-facebook"></i></a>
								</li>
								<li>
									<a href="#"><i class="fa fa-twitter"></i></a>
								</li>
								<li>
									<a href="#"><i class="fa fa-instagram"></i></a>
								</li>
								<li>
									<a href="#"><i class="fa fa-pinterest"></i></a>
								</li>
							</ul>
						</div>
					</div>
				</div>
				<!-- /row -->
			</div>
			<!-- /container -->
		</div>
		<!-- /NEWSLETTER -->

		<!-- FOOTER -->
		<footer id="footer">
			<!-- top footer -->
			<div class="section">
				<!-- container -->
				<div class="container">
					<!-- row -->
				<div class="row">
						<div class="col-md-3 col-xs-6">
							<div class="footer">
								<h3 class="footer-title">Về Chúng Tôi</h3>
								<p>Trang web bán hàng điện tử công nghệ uy tín nhất tại Việt Nam </p>
								<ul class="footer-links">
									<li><a href="#"><i class="fa fa-map-marker"></i> 80 Cao Lỗ Phường 4 Q8</a></li>
									<li><a href="#"><i class="fa fa-phone"></i>+021-95-51-84</a></li>
									<li><a href="#"><i class="fa fa-envelope-o"></i>email@email.com</a></li>
								</ul>
							</div>
						</div>

						

						<div class="clearfix visible-xs"></div>

						<div class="col-md-3 col-xs-6">
							<div class="footer">	
								<h3 class="footer-title">Thông Tin</h3>
								<ul class="footer-links">
									<li><a href="<?php echo base_url(). 'web/index' ?>">Sản phẩm</a></li>
						<li><a href="<?php echo base_url(). 'web/about' ?>">Về chúng tôi</a></li>
						<li><a href="<?php echo base_url(). 'web/chinhsachbm' ?>">Chính sách bảo mật</a></li>
						<li><a href="<?php echo base_url(). 'web/dieukhoandv' ?>">Điều khoản dịch vụ</a></li>
						<li><a href="<?php echo base_url(). 'web/contact' ?>">Liên hệ</a></li>
								</ul>
							</div>
						</div>

						<div class="col-md-3 col-xs-6">
							<div class="footer">
								<h3 class="footer-title">Sản Phẩm</h3>
								<ul class="footer-links">
													<?php 
						foreach ($menu as $key => $value) {
												
						?>
									<li class="active"><a data-toggle="tab" href="#"></a></li>
									<li><a  href="<?php echo base_url().'web/store/'.$value->idloaisp;?>"><?php echo $value->tenloaisp?></a></li>
									
									<?php 
						}?>
								</ul>
							</div>
						</div>
					</div>
					<!-- /row -->
				</div>
				<!-- /container -->
			</div>
			<!-- /top footer -->

			<!-- bottom footer -->
			<div id="bottom-footer" class="section">
				<div class="container">
					<!-- row -->
					<div class="row">
						<div class="col-md-12 text-center">
							<ul class="footer-payments">
								<li><a href="#"><i class="fa fa-cc-visa"></i></a></li>
								<li><a href="#"><i class="fa fa-credit-card"></i></a></li>
								<li><a href="#"><i class="fa fa-cc-paypal"></i></a></li>
								<li><a href="#"><i class="fa fa-cc-mastercard"></i></a></li>
								<li><a href="#"><i class="fa fa-cc-discover"></i></a></li>
								<li><a href="#"><i class="fa fa-cc-amex"></i></a></li>
							</ul>
							<span class="copyright">
								<!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
								Luận án Tốt Nghiệp &copy;<script>document.write(new Date().getFullYear());</script> Xây dựng website bán hàng (hàng điện tử) <i class="fa fa-heart-o" aria-hidden="true"></i>  <a href="https://colorlib.com" target="_blank">Colorlib</a>
							<!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
							</span>
						</div>
					</div>
						<!-- /row -->
				</div>
				<!-- /container -->
			</div>
			<!-- /bottom footer -->
		</footer>
		<!-- /FOOTER -->

		<!-- jQuery Plugins -->
		<script src="<?php echo base_url(); ?>
/assets/js/jquery.min.js"></script>
		<script src="<?php echo base_url(); ?>
/assets/js/bootstrap.min.js"></script>
		<script src="<?php echo base_url(); ?>
/assets/js/slick.min.js"></script>
		<script src="<?php echo base_url(); ?>
/assets/js/nouislider.min.js"></script>
		<script src="<?php echo base_url(); ?>
/assets/js/jquery.zoom.min.js"></script>
		<script src="<?php echo base_url(); ?>
/assets/js/main.js"></script>

	</body>
</html>
