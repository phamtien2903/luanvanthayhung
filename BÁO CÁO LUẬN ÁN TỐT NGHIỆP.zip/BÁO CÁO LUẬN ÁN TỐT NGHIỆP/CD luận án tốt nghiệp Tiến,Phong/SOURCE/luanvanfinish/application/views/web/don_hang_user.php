
<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		 <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->

		<title>Electronic Store</title>

		<!-- Google font -->
		<link href="https://fonts.googleapis.com/css?family=Montserrat:400,500,700" rel="stylesheet">

		<!-- Bootstrap -->
		<link type="text/css" rel="stylesheet" href="<?php echo base_url(); ?>
/assets/css/bootstrap.min.css"/>

		<!-- Slick -->
		<link type="text/css" rel="stylesheet" href="<?php echo base_url(); ?>
/assets/css/slick.css"/>
		<link type="text/css" rel="stylesheet" href="<?php echo base_url(); ?>
/assets/css/slick-theme.css"/>

		<!-- nouislider -->
		<link type="text/css" rel="stylesheet" href="<?php echo base_url(); ?>
/assets/css/nouislider.min.css"/>

		<!-- Font Awesome Icon -->
		<link rel="stylesheet" href="<?php echo base_url(); ?>
/assets/css/font-awesome.min.css">

		<!-- Custom stlylesheet -->
		<link type="text/css" rel="stylesheet" href="<?php echo base_url(); ?>
/assets/css/style.css"/>

		<!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
		<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
		<!--[if lt IE 9]>
		  <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
		  <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
		<![endif]-->

    </head>
	<body>
		<!-- HEADER -->
		<header>
			<!-- TOP HEADER -->
			<div id="top-header">
				<div class="container">
				<?php
			 if($this->session->userdata('logged_in') !== TRUE)
			 	{?>
					<ul class="header-links pull-left">
						<li><a href="#"><i class="fa fa-phone"></i> 0123 113 114 </a></li>
						<li><a href="#"><i class="fa fa-envelope-o"></i> email@email.com</a></li>
						<li><a href="#"><i class="fa fa-map-marker"></i> 80 Cao Lỗ Phường 4 Q8</a></li>
					</ul>
					<ul class="header-links pull-right">
						<li><a href="<?php echo base_url()?>login/index1/"></i> Dang Ky</a></li>
						<li><a href="<?php echo base_url()?>login/index/"><i class="fa fa-user-o"></i> Dang Nhap</a></li>
					</ul>
				</div>
				<?php
				}
			else
			{
				?>
				<div class="header-links pull-right">
					<?php
					//print_r($_SESSION);
					?>
					<a href=# style="color:white">	Hi, <?php echo $this->session->userdata('name') ?></a>
					<a href="<?php echo base_url() ?>web/donhang" style="color:white">	Don hang</a>
					&nbsp;&nbsp;&nbsp;&nbsp;
						<a href="<?php echo base_url()?>login/logout" style="color:white" onclick="return confirm('Bạn có chắc chắn Đăng xuất không ?')">Đăng xuất</a>
				</div>
				<?php
			}
				?>
			</div>
			<!-- /TOP HEADER -->

			<!-- MAIN HEADER -->
			<div id="header">
				<!-- container -->
				<div class="container">
					<!-- row -->
					<div class="row">
						<!-- LOGO -->
						<div class="col-md-3">
							<div class="header-logo">
								<a href="<?php echo base_url() ?>/web/index" class="logo">
									<img src="<?php echo base_url(); ?>
/assets/img/logo.png" alt="">
								</a>
							</div>
						</div>
						<!-- /LOGO -->

						<!-- SEARCH BAR -->
                  
					  
						<div class="col-md-6">
                  		<form method="post" action="<?php echo site_url('web/timkiem');?>">
							<div class="header-search">
								<form>
               
                                
								
									<input class="input" name="timkiem" placeholder="Nhập từ khóa cần tìm">

									<button class="search-btn" name="submit" type="submit" value="" >Search</button>
								</form>
							</div>
                        </form>
						</div>
                       
						<!-- /SEARCH BAR -->

						<!-- ACCOUNT -->
						<div class="col-md-3 clearfix">
							<div class="header-ctn">
								<!-- Cart -->
								<div class="dropdown">
									<a class="dropdown-toggle" data-toggle="dropdown" aria-expanded="true">
										<i class="fa fa-shopping-cart"></i>
										<span>Your Cart</span>
										<div class="qty"></div>
									</a>
									<div class="cart-dropdown">
										<div class="cart-list">
											
											<?php 

									$this->load->library('cart');
									foreach ($this->cart->contents() as $key => $value) 
											{
												?>
											<div class="product-widget">

												<div class="product-body">
													<h3 class="product-name"><a href="#"><?php echo $value['name']; ?></a></h3>
													<h4 class="product-price"><span class="qty"  ><?php echo $value['qty']; ?></span><?php echo number_format($value['price']); ?></h4>
												</div>
												<button class="delete"><i class="fa fa-close"></i></button>
											</div>
											<?php
										}
											?>
										</div>
										
										<div class="cart-btns">
											<a href="<?php base_url() ?>/mycart/show">View Cart</a>
											<a href="<?php base_url() ?>/Mycart/Checkout">Checkout  <i class="fa fa-arrow-circle-right"></i></a>
										</div>
									</div>
								</div>
								<!-- /Cart -->

								<!-- Menu Toogle -->
								<div class="menu-toggle">
									<a href="#">
										<i class="fa fa-bars"></i>
										<span>Menu</span>
									</a>
								</div>
								<!-- /Menu Toogle -->
							</div>
						</div>
						<!-- /ACCOUNT -->
					</div>
					<!-- row -->
				</div>
				<!-- container -->
			</div>
			<!-- /MAIN HEADER -->
		</header>
			<div id="breadcrumb" class="section">
			<!-- container -->
			<div class="container">
				<!-- row -->
				<div class="row">
					<div class="col-md-12">
						<h3 class="breadcrumb-header">GIỎ HÀNG</h3>
						<ul class="breadcrumb-tree">
							<li><u><a href="#" onclick="window.history.go(-1)">BACK</a></u></li>
							<li class="active">GIỎ HÀNG</li>
						</ul>
					</div>
				</div>
				<!-- /row -->
			</div>
			<!-- /container -->
		</div>
		<!-- /HEADER -->
		<div class="container">
			<div class="row">
				<div>
					<h3>ĐƠN HÀNG </h3>
					<td>
				<?php
				foreach ($donhang as $key => $value) {
					?>

					<div><?php echo $value->iddh;?>, ngay dat: <?php echo $value->ngaydat ?> 
							<p style="font-size: 15px;color: red; "><a href='<?php echo base_url() ?>web/chitietdonhang/<?php echo $value->iddh ?>'>Chi tiet</a></p>
					</div>
					<div ><?php  if ( $value->trangthai==0) echo "<p style='color:red;'>"."Chưa Duyệt"."</p>";
        						 if ( $value->trangthai==1) echo "<p style='color:orange;'>"."Đang Giao"."</p>";
        						 if ( $value->trangthai==2) echo "<p style='color:green;'>"."Đã Hoàn Thành"."</p>";	
         				 ?>
					</div>
					<div>
						          <?php 
           							if ( $value->trangthai==0) 
             						 {?>
                 <a href='<?php echo base_url() ?>web/deletedonhang/<?php  echo $value->iddh; ?>/1'><b style="color: darkred" onclick="return confirm('Bạn có chắc chắn hủy đơn hàng không ?')">Hủy đơn hàng</b></a>
          		 <p>
              
                  
            						  <?php
           								 }
           							 ?>
					</div>
					<?php
					# code...
				} ?>
			
				</td>

				</div>
			</div></div>
		<!-- /SECTION -->

		<!-- SECTION -->
	
		<!-- NEWSLETTER -->
		<div id="newsletter" class="section">
			<!-- container -->
			<div class="container">
				<!-- row -->
				<div class="row">
					<div class="col-md-12">
						<div class="newsletter">
							<p>Bạn chưa là <strong>Thành Viên ?</strong></p>
							<form>
								<input class="input" type="email" placeholder="Enter Your Email">
								<button ><a href="<?php echo base_url()?>login/index1/">Đăng Ký</button>
							</form>
							<ul class="newsletter-follow">
								<li>
									<a href="#"><i class="fa fa-facebook"></i></a>
								</li>
								<li>
									<a href="#"><i class="fa fa-twitter"></i></a>
								</li>
								<li>
									<a href="#"><i class="fa fa-instagram"></i></a>
								</li>
								<li>
									<a href="#"><i class="fa fa-pinterest"></i></a>
								</li>
							</ul>
						</div>
					</div>
				</div>
				<!-- /row -->
			</div>
			<!-- /container -->
		</div>
		<!-- /NEWSLETTER -->

		<!-- FOOTER -->
		<footer id="footer">
			<!-- top footer -->
			<div class="section">
				<!-- container -->
				<div class="container">
					<!-- row -->
					<div class="row">
						<div class="col-md-3 col-xs-6">
							<div class="footer">
								<h3 class="footer-title">Về Chúng Tôi</h3>
								<p>Trang web bán hàng điện tử công nghệ uy tín nhất tại Việt Nam </p>
								<ul class="footer-links">
									<li><a href="#"><i class="fa fa-map-marker"></i> 80 Cao Lỗ Phường 4 Q8</a></li>
									<li><a href="#"><i class="fa fa-phone"></i>+021-95-51-84</a></li>
									<li><a href="#"><i class="fa fa-envelope-o"></i>email@email.com</a></li>
								</ul>
							</div>
						</div>

						

						<div class="clearfix visible-xs"></div>

						<div class="col-md-3 col-xs-6">
							<div class="footer">	
								<h3 class="footer-title">Thông Tin</h3>
								<ul class="footer-links">
									<li><a href="<?php echo base_url(). 'web/index' ?>">Sản phẩm</a></li>
						<li><a href="<?php echo base_url(). 'web/about' ?>">Về chúng tôi</a></li>
						<li><a href="<?php echo base_url(). 'web/chinhsachbm' ?>">Chính sách bảo mật</a></li>
						<li><a href="<?php echo base_url(). 'web/dieukhoandv' ?>">Điều khoản dịch vụ</a></li>
						<li><a href="<?php echo base_url(). 'web/contact' ?>">Liên hệ</a></li>
								</ul>
							</div>
						</div>

						<div class="col-md-3 col-xs-6">
							<div class="footer">
								<h3 class="footer-title">Sản Phẩm</h3>
								<ul class="footer-links">
													<?php 
						foreach ($menu as $key => $value) {
												
						?>
									<li class="active"><a data-toggle="tab" href="#"></a></li>
									<li><a  href="<?php echo base_url().'web/store/'.$value->idloaisp;?>"><?php echo $value->tenloaisp?></a></li>
									
									<?php 
						}?>
								</ul>
							</div>
						</div>
					</div>
					<!-- /row -->
				</div>
				<!-- /container -->
			</div>
			<!-- /top footer -->

			<!-- bottom footer -->
			<div id="bottom-footer" class="section">
				<div class="container">
					<!-- row -->
					<div class="row">
						<div class="col-md-12 text-center">
							<ul class="footer-payments">
								<li><a href="#"><i class="fa fa-cc-visa"></i></a></li>
								<li><a href="#"><i class="fa fa-credit-card"></i></a></li>
								<li><a href="#"><i class="fa fa-cc-paypal"></i></a></li>
								<li><a href="#"><i class="fa fa-cc-mastercard"></i></a></li>
								<li><a href="#"><i class="fa fa-cc-discover"></i></a></li>
								<li><a href="#"><i class="fa fa-cc-amex"></i></a></li>
							</ul>
							<span class="copyright">
								<!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
								Luận án Tốt Nghiệp &copy;<script>document.write(new Date().getFullYear());</script> Xây dựng website bán hàng (hàng điện tử) <i class="fa fa-heart-o" aria-hidden="true"></i>  <a href="https://colorlib.com" target="_blank">Colorlib</a>
							<!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
							</span>
						</div>
					</div>
						<!-- /row -->
				</div>
				<!-- /container -->
			</div>
			<!-- /bottom footer -->
		</footer>
		<!-- /FOOTER -->

		<!-- jQuery Plugins -->
		<script src="<?php echo base_url(); ?>
/assets/js/jquery.min.js"></script>
		<script src="<?php echo base_url(); ?>
/assets/js/bootstrap.min.js"></script>
		<script src="<?php echo base_url(); ?>
/assets/js/slick.min.js"></script>
		<script src="<?php echo base_url(); ?>
/assets/js/nouislider.min.js"></script>
		<script src="<?php echo base_url(); ?>
/assets/js/jquery.zoom.min.js"></script>
		<script src="<?php echo base_url(); ?>
/assets/js/main.js"></script>

	</body>
</html>
	