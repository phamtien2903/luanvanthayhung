Da them thanh cong.
<hr>
<a href="<?php echo base_url()?>admin">Xem</a>