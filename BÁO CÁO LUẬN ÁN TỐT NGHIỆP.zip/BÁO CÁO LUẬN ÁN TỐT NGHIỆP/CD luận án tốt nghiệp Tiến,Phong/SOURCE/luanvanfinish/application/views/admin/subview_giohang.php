<div class="card-header">
  <i class="fas fa-table"></i>
  Data Table Example</div>
<div class="card-body">
  <div class="table-responsive">
    <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
      <thead>
        <tr>
          
          <th>ID</th>
          <th>Name</th>
          <th>Total</th>
          <th>Ngày nhận đơn hàng</th>
           <th>Trạng Thái</th>
          <th>Thao tác</th>
        </tr>
      </thead>
      <tbody>
        <?php
        foreach ($data as $key => $value) 
        {
         ?>
         <tr>
          
          <td>
            <?php echo $value->idkh; ?>
          </td>
          <td>
          <a href='#'>
            <?php 
            echo $value->iddh;
            ?>
           </a>
         </td>
         <td><?php echo $value->tongtiendh; ?></td>
         <td><?php echo $value->ngaydat; ?></td>
         <td><?php  if ( $value->trangthai==0) echo "Chua duyet";
         if ( $value->trangthai==1) echo "dang giao";
         if ( $value->trangthai==2) echo "Hoan thanh";


          ?></td>
         <td>
          <?php 
            if ( $value->trangthai==0) 
              {?>
                 <a href='<?php echo base_url() ?>admin/thaydoitrangthai/<?php  echo $value->iddh; ?>/1'><i onclick="return confirm('Bạn có chắc chắn giao hàng không ?')">Giao Hang</i></a>
           <p>
              
                  
              <?php
            }

             if ( $value->trangthai==1) 
              {?>
                <a href='<?php echo base_url() ?>admin/thaydoitrangthai/<?php  echo $value->iddh; ?>/2'>
                 <i onclick="return confirm('Bạn có chắc chắn hoàn thành đơn hàng không ?')">Hoan thanh Hang </i></a>
          
              <?php
            }

             if ( $value->trangthai==2) 
              { echo "Da Hoan Thanh ";
              
            }
              ?>
               
          </td>
        </tr>
        <?php
      }
        ?>
      </tbody>
    </table>
  </div>
</div>
<div class="card-footer small text-muted">Updated yesterday at 11:59 PM</div>
