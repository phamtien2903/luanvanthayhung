
<?php    

 echo $this->table->generate($data); // tạo table
 echo $this->pagination->create_links(); // tạo link phân trang ?>