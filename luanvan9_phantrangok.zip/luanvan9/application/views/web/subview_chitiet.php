	<div class="col-md-5">
						<div class="product-details">
							<h2 class="product-name"><?php
                           // print_r($data1);
						   echo $data1['tensp'];
							?></h2>
							<div>
								
								<a class="review-link" href="#">10 Review(s) | Add your review</a>
							</div>
							<div>
								<h3 class="product-price"><?php echo $data1['giasp']; ?><del class="product-old-price">$990.00</del></h3>
								<span class="product-available">In Stock</span>
							</div>
							<p><?php echo $data1['motasp']?></p>

							<div class="product-options">
								
							</div>

							<div class="add-to-cart">
								<div class="qty-label">
									</div>
								<button class="add-to-cart-btn"><i class="fa fa-shopping-cart"></i> add to cart</button>
							</div>

							

							<ul class="product-links">
								<li>LOẠI SẢN PHẨM:</li>
								<li><a href="#"><?php echo $data1['tenloaisp'];?></a></li>
							<li class="active"><?php echo $data1['tensp'];?></li>
							</ul>

							<ul class="product-links">
								<li>Share:</li>
								<li><a href="#"><i class="fa fa-facebook"></i></a></li>
								<li><a href="#"><i class="fa fa-twitter"></i></a></li>
								<li><a href="#"><i class="fa fa-google-plus"></i></a></li>
								<li><a href="#"><i class="fa fa-envelope"></i></a></li>
							</ul>

						</div>
					</div>