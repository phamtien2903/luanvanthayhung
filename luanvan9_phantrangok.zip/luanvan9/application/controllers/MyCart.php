<?php
/**
 * 
 */

class MyCart extends CI_Controller
{
	function __construct()
	{
		parent::__construct();
		$this->load->library('cart');
	}
/*
	function add_to_cart(){ 
		//print_r($_POST);
		
		$data = array(
			'id' => $this->input->post('book_id'), 
			'name' => $this->input->post('book_name'), 
			'price' => $this->input->post('price'), 
			'qty' => $this->input->post('qty'), 
		);

		$this->cart->insert($data);

		$this->cart->contents();
		echo $this->show_cart(); 
	}

	function show_cart(){ 
		$output = '';
		$no = 0;
		foreach ($this->cart->contents() as $items) {
			$no++;
			$output .='
				<tr>
					<td>'.$items['name'].'</td>
					<td>'.number_format($items['price']).'</td>
					<td>'.$items['qty'].'</td>';
					//'<td>'.number_format($items['subtotal']).'</td>
			$output .='<td><button type="button" id="'.$items['rowid'].'" class="romove_cart btn btn-danger btn-sm">Delete</button></td>
				</tr>
			';
		}
		$output .= '
			<tr>
				<th colspan="3">Total</th>
				<th colspan="2">'.'Rp '.number_format($this->cart->total()).'</th>
			</tr>
		';
		return $output;
	}

	function load_cart(){ 
		echo $this->show_cart();
	}

	function delete_cart(){ 
		$data = array(
			'rowid' => $this->input->post('row_id'), 
			'qty' => 0, 
		);
		$this->cart->update($data);
		echo $this->show_cart();
	}
*/

//===============================================
	function add()
	{
/*print_r($_POST);
		exit;*/
		//echo "<pre>";
			$data = array(
			'id' 	=> $this->input->post('idsp'), 
			'name' 	=> $this->input->post('tensp'), 
			'price' => $this->input->post('giasp'), 
			'qty' 	=> $this->input->post('soluong'), 
		);

		$this->cart->insert($data);

		//$this->cart->contents();
		//print_r( $this->cart->contents()); 

		redirect('mycart/show');
	}

	function show()
	{
		$this->load->model('MSanpham');
		
		$menu =$this->MSanpham->menu();
		
		$this->load->view('web/my_page', ['menu'=>$menu,'subview'=> 'web/subview_cart']);

	}

	function del($rowid)
	{
		$data = array('rowid'=>$rowid, 'qty'=>0);
		$this->cart->update($data);
		redirect('mycart/show');
		//print_r( $this->cart->contents());
		//redirect('cart.html');
	}
	function update()
	{
		$data = array(
			'rowid'	=>$this->input->post('rowid'),
			'qty'	=>$this->input->post('qty')<0?0:$this->input->post('qty')
		);
		$this->cart->update($data);
		redirect('mycart/show');
	/*	echo "<pre>";
		print_r( $this->cart->contents()); */
		//redirect('cart.html');
	}

	function checkout()
	{
		 if($this->session->userdata('logged_in') !== TRUE)
		 {
      		redirect(base_url().'login');
      	 }

      	 if (count($this->cart->contents()) == 0)
      	 {
      	 	redirect(base_url());
      	 }

      	 $this->load->view('web/my_page', ['subview'=>'web/subview_checkout']);
	}

	function finish()
	{
		 if($this->session->userdata('logged_in') !== TRUE)
		 {
      		redirect(base_url().'login');
      	 }

      	 if (count($this->cart->contents()) == 0)
      	 {
      	 	redirect(base_url());
      	 }

      	$iddh = $this->session->userdata('email').'_'. time();
      	$data1 = array();
      	$data1['iddh']		=$iddh;
      	$data1['idkh'] 		= $this->session->userdata('idkh');
      	$data1['ngaydat']			= Date('Y-m-d');
      	$data1['tennguoinhan']	= $this->input->post('tennguoinhan');
      	$data1['dcnguoinhan']		= $this->input->post('dcnguoinhan');
      	$data1['sdtnguoinhan']	= $this->input->post('sdtnguoinhan');
      	$data1['trangthai']	= 0;
      	$data2 =array();

      	$bodyCart= "<table><tr><td>Ten </td><td>SL</td><td>Gia</td>";
      	$total =0;
      	foreach ($this->cart->contents() as $key => $value) 
      	{
      		//print_r($value);

      		$row = array('iddh'=>$iddh, 'idsp'=>$value['id'],'soluong'=>$value['qty'], 'gia'=>$value['price']);
      		$data2[]= $row;	

      		$tr ="<tr><td>{$value['name']} </td><td>{$value['qty']}</td><td>{$value['price']}</td>";
      		$tr .="<td><a href='" . base_url()."web/chitiet/".$value['id']."'>Xem</a></td>";
      		$bodyCart .= $tr;
      		$total += $value['price'] * $value['qty'];
      	}
      	$tr = $tr ="<tr><td colspan=2>Tong tien </td><td>$total</td>";
		//echo "<pre>";print_r($data1); print_r($data2);
		$data1['tongtiendh'] = $total;
      	$this->load->model('MCart');
      	if ($this->MCart->insertOrder($data1))
      		$this->MCart->saveOrderDetail($data2);
      

      	$from_email = "phongnguyentest123@gmail.com"; //Email khi khách hàng nhận mail và bấm reply -> sẽ gửi tới dchi này
        $to_email = $this->session->userdata('email');
        $subject = 'Thông tin đơn hàng';
      
        $body 	= $bodyCart;
           
		$config = array();
		$config['protocol'] = 'smtp';
		$config['smtp_host'] = 'ssl://smtp.googlemail.com';
		//$config['smtp_host'] = 'tls://smtp.googlemail.com';
		$config['smtp_user'] = 'phongnguyentest123@gmail.com';
		$config['smtp_pass'] = 'Phong12341234'; 
		$config['smtp_port'] = 465;
		//$config['smtp_port'] = 579;
		$config['mailtype']  = 'html';
        $config['starttls']  = true;
        $config['newline']   = "\r\n";

		$this->load->library('email', $config);
		$this->email->initialize($config);
        $this->email->from($from_email, 'Cong Ty phu tung dien tu');
        $this->email->to($to_email);
        $this->email->subject($subject);
        $this->email->message($body);
      
        //Send mail
        if($this->email->send())
        {
            $this->session->set_flashdata("email_sent","Successfully.");

        }
        else{
            $this->session->set_flashdata("email_sent","You have encountered an error");
             ob_start();
			  $this->email->print_debugger();
			  $error = ob_end_clean();
			  $errors[] = $error;
			 // print_r($errors);

        }
       // $this->cart->destroy();
        $this->load->view('web/cartfinish');

		
	}
}