<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Login extends CI_Controller
{
  function __construct()
  {
    parent::__construct();
    $this->load->model('Mlogin');
  }
 
  function index()
  {
    $this->load->view('web/layout_login');//,['subview'=>'web/subview_login']);
  }
  function index1()
  {
    $this->load->view('web/layout_register');//,['subview'=>'web/subview_register']);
  }
 
  function auth()
  {
    $email    = $this->input->post('email',TRUE);
    $password = md5($this->input->post('password',TRUE));
    $validate = $this->Mlogin->validate($email,$password);
    if($validate->num_rows() > 0)
    {
        $data  = $validate->row_array();
        $name  = $data['hotenkh'];
        $email = $data['email'];
        $level = $data['level'];
        $idkh = $data['idkh'];
        $diachikh = $data['diachikh'];
        $dienthoaikh = $data['dienthoaikh'];
        $sesdata = array(
            'name'  => $name,
            'email'     => $email,
            'level'     => $level,
            'idkh'      => $idkh,
            'diachikh'  => $diachikh,
            'dienthoaikh'=>$dienthoaikh,
            'logged_in' => TRUE
        );
        $this->session->set_userdata($sesdata);
        if($level === '1'){
            redirect(base_url().'admin');
 
        // access login for author
        }else{
            redirect(base_url());
        }
    }
    else{
        echo $this->session->set_flashdata('msg','Username or Password is Wrong');
        redirect(base_url().'login');
    }
  }
 

  function logout(){
      $this->session->sess_destroy();
      // $this->session->unset_userdata('name');
      //$this->session->unset_userdata('logged_in');

      redirect(base_url().'web/index');
  }

  function insertdk()
  {
    $this->load->model('MSanpham');
    
    
    $data = array();
    $data['idkh'] =  time(); // $this->input->post('idkh');
    $data['hotenkh'] = $this->input->post('hotenkh');
    $data['dienthoaikh'] = $this->input->post('dienthoaikh');
    $data['email'] = $this->input->post('email');
    $data['password'] = md5( $this->input->post('password') );
    $data['ngaysinhkh'] = $this->input->post('ngaysinhkh');
    $data['gioitinhkh'] = $this->input->post('gioitinhkh');
    $data['diachikh'] = $this->input->post('diachikh');
    
   
   
   
    
    //$this->db->insert('binhluan', $data);
    //$data['time'] = $this->input->post('time');
    
    
    $data = $this->MSanpham->dangky($data);
    
    
     //redirect(base_url().'web/product','refresh'); 
     $this->load->view('web/bluan_success', $data);
  }
}

