<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Web extends CI_Controller {

	
	public function index()
	{
		$this->load->model('MSanpham');
		$loaisp = $this->MSanpham->loaisp();
		$moi = $this->MSanpham->sanphammoi();
		$banchay = $this->MSanpham->sanphambanchay();
		$menu =$this->MSanpham->menu();
		$this->load->view('web/my_page', ['loaisp'=>$loaisp, 'spmoi'=>$moi,'spbanchay'=>$banchay, 'menu'=>$menu,'subview'=>'web/subview_index','submenu'=>'web/subview_menu']);
	}

	public function detail()
	{
		$this->load->model('MSanpham');
		$loaisp = $this->MSanpham->loaisp();
		$menu =$this->MSanpham->menu();
		$moi = $this->MSanpham->sanphammoi();
		$banchay = $this->MSanpham->sanphambanchay();
		$data =  array('subview'=>'web/subview_index','loaisp'=>$loaisp ,'menu'=>$menu, 'spmoi'=>$moi, 'spbanchay'=>$banchay);

		$this->load->view('web/my_page', $data);
	}
	public function product()
	{
			$this->load->view('web/product');
	}
	public function blank()
	{
		$this->load->view('web/blank');
	}
	


		public function timkiem()
	{
	
		$timkiem = $this->input->post('timkiem');
		//echo "<pre>";print_r($timkiem);exit;
		$this->load->model('MSanpham');
		$data = $this->MSanpham->timkiem($timkiem);
			$data2 = $this->MSanpham->menu();

		//$timkiem=$this->MSanpham->timkiem($timkiem);
		//load view
		$this->load->view('web/sptimkiemdc', ['data1'=>$data2,'timkiem'=>$data]);
		
	}
	public function contact()
	{
		$this->load->view('bonus/contact');
	}
	public function about()
	{
		$this->load->view('bonus/about');
	}
	public function chinhsachbm()
	{
		$this->load->view('bonus/chinhsachbm');
	}
	public function dieukhoandv()
	{
		$this->load->view('bonus/dieukhoandv');
	}
		public function binhluan($idbl){
    // if nothing posted redirect
    if (!$this->input->post()) {
        redirect(site_url().'web/binhluan');
    }

    // TODO: save comment in database
    $this->load->model('MSanpham');

    $result = $this->MSanpham-> binhluan($idbl);
    //if ($result !== false) {
    //    redirect('posts/'.$idbl);
    //}

    $this->load->view('web/binhluan', ['binhluan'=>$result]);
}
	
	
	public function phantrang	()
		 	{
		 		$this->load->model('MSanpham');
           // load thư viện cần thiết
            $this->load->library('pagination');
            $this->load->helper('url');
            $this->load->library('table');
            
            // cấu hình phân trang
            $config['base_url'] = base_url('web/phantrang'); // xác định trang phân trang
            $config['total_rows'] = $this->MSanpham->count_all(); // xác định tổng số record
            $config['per_page'] = 5; // xác định số record ở mỗi trang
            $config['uri_segment'] = 3; // xác định segment chứa page number
            	$this->pagination->initialize($config);
            
            // tạo table
            $this->table->set_heading('id','name');
            $data['data'] = $this->MSanpham->list_all($config['per_page'],$this->uri->segment(3));
            
            $this->load->view('bonus/phantrang',$data);
        }
        	public function chitiet($idsp)
	{
		$this->load->model('MSanpham');
		//
		// load thư viện cần thiết
            $this->load->library('pagination');
            $this->load->helper('url');
            $this->load->library('table');
            //
             // cấu hình phân trang 

            $config['base_url'] = base_url('web/chitiet/'.$idsp); // xác định trang phân trang
            $config['total_rows'] =  $this->MSanpham->count_allbl(); // xác định tổng số record
            $config['per_page'] = 1	; // xác định số record ở mỗi trang
            $config['uri_segment'] = 4; // xác định segment chứa page number
          	 $this->pagination->initialize($config);
          	 $offset = $this->uri->segment(4)*1; 
            $test = $this->MSanpham->list_allbl($config['per_page'], $offset);

		$menu = $this->MSanpham->menu();
		$binhluan = $this->MSanpham->allbinhluan();
		$data = $this->MSanpham->chitiet($idsp);
		//echo "<pre>";print_r($data);exit;
			$data2= $this->MSanpham->spcungloai($data['idloaisp']);
		
		//print_r($data);exit;
		$this->load->view('web/product', ['menu'=>$menu,'data1'=>$data,'spkhac'=>$data2,'test'=>$test,'binhluan'=>$binhluan,'subview1'=>'web/subview_chitiet']);
	}

     public function store($idloaisp)
	{
		$this->load->model('MSanpham');
		//
		// load thư viện cần thiết
            $this->load->library('pagination');
            $this->load->helper('url');
            $this->load->library('table');
            //
           
             $this->MSanpham->spcungloaistore($idloaisp );
            // cấu hình phân trang 

            $config['base_url'] = base_url('web/store/'.$idloaisp); // xác định trang phân trang
            $config['total_rows'] =  $this->MSanpham->count_all($idloaisp); // xác định tổng số record
            $config['per_page'] = 6; // xác định số record ở mỗi trang
            $config['uri_segment'] = 4; // xác định segment chứa page number
          	 $this->pagination->initialize($config);
          	
         
         //  print_r($config);exit;
          	// $offset = ($page_number  == 1) ? 0 : ($page_number * $config['per_page']) - $config['per_page'];
          	$offset = $this->uri->segment(4)*1; 
            $test = $this->MSanpham->list_all($config['per_page'], $offset, $idloaisp);
            //$pag = $this->pagination->create_links();
		//
		$data = $this->MSanpham->menu();
		$menuct = $this->MSanpham->menuct($idloaisp);
		$noidung = $this->MSanpham->noidung($idloaisp);
		$this->load->view('web/store',['menuct'=>$menuct,'data1'=>$data,'noidung'=>$noidung,'test'=>$test,'subviewstore'=>'web/subview_store']);
	}   

      public function storemuc($idloaisp)
	{
		//echo "Loai: $idloaisp ===";
		$this->load->model('MSanpham');
		//
		// load thư viện cần thiết
            $this->load->library('pagination');
            $this->load->helper('url');
            $this->load->library('table');
            //
           
             $this->MSanpham->spcungloaistore($idloaisp );
            // cấu hình phân trang 

            $config['base_url'] = base_url('web/storemuc/'.$idloaisp); // xác định trang phân trang
            $config['total_rows'] =  $this->MSanpham->count_all($idloaisp); // xác định tổng số record
            $config['per_page'] = 5; // xác định số record ở mỗi trang
            $config['uri_segment'] = 4; // xác định segment chứa page number
          	 $this->pagination->initialize($config);
          	
         
         //  print_r($config);exit;
          	// $offset = ($page_number  == 1) ? 0 : ($page_number * $config['per_page']) - $config['per_page'];
          	$offset = $this->uri->segment(4)*1; 
            $test = $this->MSanpham->list_all($config['per_page'], $offset, $idloaisp);
            //$pag = $this->pagination->create_links();
		//
		$data = $this->MSanpham->menu();
		$menuct = $this->MSanpham->menuct($idloaisp);
		$noidung = $this->MSanpham->noidung($idloaisp);
		//$data2 = $this->MSanpham->chitiet($idsp);
		//echo "<pre>";print_r($data);exit;
		///$spcungloaistore= $this->MSanpham->spcungloaistore($idloaisp );
		//phan trang

		$this->load->view('web/storemuc',['menuct'=>$menuct,'data1'=>$data,'noidung'=>$noidung ,'test'=>$test]);
	}

			public function bluan()
	{
		$this->load->model('MSanpham');
		
		
		$data = array();
		$data['idbl'] = $this->input->post('idbl');
		$data['user'] = $this->input->post('user');
		$data['email'] = $this->input->post('email');
		$data['comments'] = $this->input->post('comments');
		$this->db->set('time', 'NOW()', FALSE);
		//$this->db->insert('binhluan', $data);
		//$data['time'] = $this->input->post('time');
		
		
		$data = $this->MSanpham->bluan($data);
		
		
		 //redirect(base_url().'web/product','refresh'); 
		 $this->load->view('web/bluan_success', $data);

	
		
	}
	public function deletebluan($id='')
	{
		$this->load->model('MSanpham');
		$this->MSanpham->deletebluan($id);
		$this->load->view('web/bluan_success');
	}
	
}
?>