<?php

foreach($book as $r)
{
	//echo "<br>" . $r['book_id'];
	echo "<br>" . $r->idsp;
	
}

?>

