<div class="a"  >
	<a href="#" onclick="window.history.go(-1)">Nhấp để quay về trang</a>
	<p style="color: green"> Bạn đã đăng nhập thành công</p>
	
</div>