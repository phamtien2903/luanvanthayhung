<?php
class MLogin extends CI_Model{
 
  function validate($email,$password){
    $this->db->where('email',$email);
    $this->db->where('password',$password);
    $result = $this->db->get('user',1);
    //echo $this->db->last_query();exit;
    return $result;
  }

  function insert($data)
	{
		
		$insert =$this->db->insert('user', $data);
		if (!$insert ) 
		{
   			echo "Err.Loi them...";exit;
		} else 
		{
  			echo "Ok,". $this->db->last_query();//exit;
		}
	}
 
}