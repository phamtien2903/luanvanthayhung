<!-- NAVIGATION -->
		<nav id="navigation">
			<!-- container -->
			<div class="container">
				<!-- responsive-nav -->
				<div id="responsive-nav">
					<!-- NAV -->
						
			<ul class="main-nav nav navbar-nav">
						
						<ul class="section-tab-nav tab-nav">
										<?php 
						foreach ($menu as $key => $value) {
												
						?>
									<li class="active"><a data-toggle="tab" href="#">||</a></li>
									<li><a  href="<?php echo base_url().'web/store/'.$value->idloaisp;?>"><?php echo $value->tenloaisp?></a></li>
									
									<?php 
						}?>
						
								</ul>
							<ul>
								

							</ul>

						</a></li>
						
					
					</ul>
					
					<!-- /NAV -->
				</div>
				<!-- /responsive-nav -->
			</div>
			<!-- /container -->
		</nav>
		<!-- /NAVIGATION -->

		<!-- SECTION -->
		<div class="section">
			<!-- container -->
			<div class="container">
				<!-- row -->
				<div class="row">

					<!-- section title -->
					<div class="col-md-12">
						<div class="section-title">
							<h3 class="title">Sản Phẩm Mới</h3>
							</div>

						</div>
					</div>
					<!-- /section title -->

					<!-- Products tab & slick -->
					<div class="col-md-12">
						<div class="row">
							<div class="products-tabs">
								<!-- tab -->
								<div id="tab1" class="tab-pane active">
									<div class="products-slick" data-nav="#slick-nav-1">
										<!-- product -->
                                    
                                      <?php
									foreach ($spmoi as $key => $value) 
									{		 
										
										?>                      
                                       
										<div class="product" >
											<div class="product-img">
												<img src="<?php echo base_url(); ?>assets/img/sanpham/<?php echo $value->mausp ?>" alt="">
												<div class="product-label">
													<span class="sale">-30%</span>
													<span class="new">NEW</span>
												</div>
											</div>

											<div class="product-body" >
													
												<p class="product-category"><?php echo $value->tenloaisp ?></p>
												<h3 class="product-name"><a href='<?php echo base_url(); ?>web/chitiet	/<?php echo $value->idsp; ?>'  ><?php echo "$value->tensp" ?></a></h3>
												<h4 class="product-price"><?php echo "$value->giasp" ?> <del class="product-old-price">$990.00</del></h4>
												<div class="product-rating">
													<i class="fa fa-star"></i>
													<i class="fa fa-star"></i>
													<i class="fa fa-star"></i>
													<i class="fa fa-star"></i>
													<i class="fa fa-star"></i>
													
												</div>
												<div class="product-btns">
													<button class="add-to-wishlist"><i class="fa fa-heart-o"></i><span class="tooltipp">add to wishlist</span></button>
													<button class="add-to-compare"><i class="fa fa-exchange"></i><span class="tooltipp">add to compare</span></button>
													<button class="quick-view"><i class="fa fa-eye"></i><span class="tooltipp">quick view</span></button>
												</div>
											</div>
											<div class="add-to-cart">
												<button class="add-to-cart-btn">
													<a href="#" onclick="form_<?php echo $value->idsp;?>.submit();"><i class="fa fa-shopping-cart" >add to cart</i> </a></button>
											</div>
										</div>
										
			<form action="<?php echo base_url() ?>mycart/add" method="post" accept-charset="utf-8" id='form_<?php echo $value->idsp; ?>' style="float: right;">
				<input type="hidden" name="idsp" value="<?php echo $value->idsp; ?>">
				<input type="hidden" name="soluong" value="1">
				<input type="hidden" name="giasp" value="<?php echo $value->giasp; ?>">
				<input type="hidden" name="tensp" value="<?php echo $value->tensp; ?>">
			</form>

		
                                        <?php
											
											}
										?>
                                         
										<!-- /product -->

										<!-- product -->
										
										<!-- /product -->

										<!-- product --><!-- /product -->

										<!-- product --><!-- /product -->

										<!-- product --><!-- /product -->
									</div>
									<div id="slick-nav-1" class="products-slick-nav"></div>
								</div>
								<!-- /tab -->
							</div>
						</div>
					</div>
					<!-- Products tab & slick -->
				</div>
				<!-- /row -->
			</div>
			<!-- /container -->
		</div>
		<!-- /SECTION -->

		<!-- HOT DEAL SECTION -->
		<div id="hot-deal" class="section">
			<!-- container -->
			<div class="container">
				<!-- row -->
				<div class="row">
					<div class="col-md-12">
						<div class="hot-deal">
							<ul class="hot-deal-countdown">
								<li>
									<div>
										<h3>02</h3>
										<span>Days</span>
									</div>
								</li>
								<li>
									<div>
										<h3>10</h3>
										<span>Hours</span>
									</div>
								</li>
								<li>
									<div>
										<h3>34</h3>
										<span>Mins</span>
									</div>
								</li>
								<li>
									<div>
										<h3>60</h3>
										<span>Secs</span>
									</div>
								</li>
							</ul>
							<h2 class="text-uppercase">hot deal this week</h2>
							<p>New Collection Up to 50% OFF</p>
							<a class="primary-btn cta-btn" href="#">Shop now</a>
						</div>
					</div>
				</div>
				<!-- /row -->
			</div>
			<!-- /container -->
		</div>
		<!-- /HOT DEAL SECTION -->

		<!-- SECTION -->
		<div class="section">
			<!-- container -->
			<div class="container">
				<!-- row -->
				<div class="row">

					<!-- section title -->
					<div class="col-md-12">
						<div class="section-title">
							<h3 class="title">Sản Phẩm Bán Chạy</h3>
							<div class="section-nav">	
								
							</div>
						</div>
					</div>
					<!-- /section title -->

					<!-- Products tab & slick -->
					<div class="col-md-12">
						<div class="row">
							<div class="products-tabs">
								<!-- tab -->
								<div id="tab2" class="tab-pane fade in active">
									<div class="products-slick" data-nav="#slick-nav-2">
										<!-- product -->
										<?php
										foreach ($spbanchay as $key => $value) 
										{
										?>
										<div class="product">
											<div class="product-img">
												<img src="<?php echo base_url(); ?>
assets/img/sanpham/<?php echo $value->mausp ?>" alt="">
												<div class="product-label">
													<span class="sale">-30%</span>
													<span class="new">NEW</span>
												</div>
											</div>
											<div class="product-body">
												<h2 class="product-category"><?php echo $value->tenloaisp;?></h2>
                                               
												<h3 class="product-name">
                                            <a href="<?php echo base_url() . 'web/chitiet/'.$value->idsp; ?>"><?php echo $value->tensp?></a></h3>
												<h4 class="product-price"><?php echo $value->giasp?> <del class="product-old-price">$990.00</del></h4>
												<div class="product-rating">
													<i class="fa fa-star"></i>
													<i class="fa fa-star"></i>
													<i class="fa fa-star"></i>
													<i class="fa fa-star"></i>
													<i class="fa fa-star"></i>
												</div>
												<div class="product-btns">
													<button class="add-to-wishlist"><i class="fa fa-heart-o"></i><span class="tooltipp">add to wishlist</span></button>
													<button class="add-to-compare"><i class="fa fa-exchange"></i><span class="tooltipp">add to compare</span></button>
													<button class="quick-view"><i class="fa fa-eye"></i><span class="tooltipp">quick view</span></button>
												</div>
											</div>
											<div class="add-to-cart">
												<button class="add-to-cart-btn">
													<a href="#" onclick="form_<?php echo $value->idsp;?>.submit();"><i class="fa fa-shopping-cart" >add to cart</i> </a></button>
											</div>
										</div>
	<form action="<?php echo base_url() ?>mycart/add" method="post" accept-charset="utf-8" id='form_<?php echo $value->idsp; ?>' style="float: right;">
				<input type="hidden" name="idsp" value="<?php echo $value->idsp; ?>">
				<input type="hidden" name="soluong" value="1">
				<input type="hidden" name="giasp" value="<?php echo $value->giasp; ?>">
				<input type="hidden" name="tensp" value="<?php echo $value->tensp; ?>">
			</form>

										<?php
											}
										?>
										<!-- /product -->

										<!-- product -->
										
										<!-- /product -->
									</div>
									<div id="slick-nav-2" class="products-slick-nav"></div>
								</div>
								<!-- /tab -->
							</div>
						</div>
					</div>
					<!-- /Products tab & slick -->
				</div>
				<!-- /row -->
			</div>
			<!-- /container -->
		</div>