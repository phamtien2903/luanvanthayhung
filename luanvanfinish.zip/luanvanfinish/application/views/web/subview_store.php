
<?php
										foreach ($test as $key => $value) 
										{
										?>
										<div class="col-md-4 col-xs-6">
								<div class="product">
									<div class="product-img">
										<img src="<?php echo base_url()?>assets/img/sanpham/<?php echo $value['mausp'] ?>" alt="">
										<div class="product-label">
											<span class="sale">-30%</span>
											<span class="new">NEW</span>
										</div>
									</div>
									<div class="product-body">
										<p class="product-category">Category</p>
										<h3 class="product-name"><a href="<?php echo base_url() . 'web/chitiet/'.$value['idsp']; ?>"><?php echo $value['tensp'];?>
											
										</a></h3>
										<h4 class="product-price"><?php echo $value['giasp'];?><del class="product-old-price">$990.00</del></h4>
										<div class="product-rating">
											<i class="fa fa-star"></i>
											<i class="fa fa-star"></i>
											<i class="fa fa-star"></i>
											<i class="fa fa-star"></i>
											<i class="fa fa-star"></i>
										</div>
										<div class="product-btns">
											<button class="add-to-wishlist"><i class="fa fa-heart-o"></i><span class="tooltipp">add to wishlist</span></button>
											<button class="add-to-compare"><i class="fa fa-exchange"></i><span class="tooltipp">add to compare</span></button>
											<button class="quick-view"><i class="fa fa-eye"></i><span class="tooltipp">quick view</span></button>
										</div>
									</div>
									<div class="add-to-cart">
										<button class="add-to-cart-btn">
													<a href="#" onclick="form_<?php echo $value['idsp'];?>.submit();"><i class="fa fa-shopping-cart" >add to cart</i> </a></button>
									</div>
								</div>
								<form action="<?php echo base_url() ?>mycart/add" method="post" accept-charset="utf-8" id='form_<?php echo $value['idsp']; ?>' style="float: right;">
				<input type="hidden" name="idsp" value="<?php echo $value['idsp']; ?>">
				<input type="hidden" name="soluong" value="1">
				<input type="hidden" name="giasp" value="<?php echo $value['giasp']; ?>">
				<input type="hidden" name="tensp" value="<?php echo $value['tensp']; ?>">
			</form>
							</div>
							<?php 
						}?>