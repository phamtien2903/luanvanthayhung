<script language="javascript">
alert("Đăng ký thành công ");
setTimeout( function() {
           history.go(-2);
      }), 10000;
</script>