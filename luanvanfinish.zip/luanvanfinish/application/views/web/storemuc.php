<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		 <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->

		<title>Electro - HTML Ecommerce Template</title>

 		<!-- Google font -->
 		<link href="https://fonts.googleapis.com/css?family=Montserrat:400,500,700" rel="stylesheet">

 		<!-- Bootstrap -->
 		<link type="text/css" rel="stylesheet" href="<?php echo base_url(); ?>
/assets/css/bootstrap.min.css"/>

 		<!-- Slick -->
 		<link type="text/css" rel="stylesheet" href="<?php echo base_url(); ?>
/assets/css/slick.css"/>
 		<link type="text/css" rel="stylesheet" href="<?php echo base_url(); ?>
/assets/css/slick-theme.css"/>

 		<!-- nouislider --> 
 		<link type="text/css" rel="stylesheet" href="<?php echo base_url(); ?>
/assets/css/nouislider.min.css"/>

 		<!-- Font Awesome Icon -->
 		<link rel="stylesheet" href="<?php echo base_url(); ?>
/assets/css/font-awesome.min.css">

 		<!-- Custom stlylesheet -->
 		<link type="text/css" rel="stylesheet" href="<?php echo base_url(); ?>
/assets/css/style.css"/>

		<!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
		<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
		<!--[if lt IE 9]>
		  <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
		  <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
		<![endif]-->

    </head>
	<body>
		<!-- HEADER -->
		<header>
			<!-- TOP HEADER -->
		<div id="top-header">
				<div class="container">
				<?php
			 if($this->session->userdata('logged_in') !== TRUE)
			 	{?>
					<ul class="header-links pull-left">
						<li><a href="#"><i class="fa fa-phone"></i> 0123 113 114 </a></li>
						<li><a href="#"><i class="fa fa-envelope-o"></i> email@email.com</a></li>
						<li><a href="#"><i class="fa fa-map-marker"></i> 80 Cao Lỗ Phường 4 Q8</a></li>
					</ul>
					<ul class="header-links pull-right">
						<li><a href="<?php echo base_url()?>login/index1/"></i> Dang Ky</a></li>
						<li><a href="<?php echo base_url()?>login/index/"><i class="fa fa-user-o"></i> Dang Nhap</a></li>
					</ul>
				</div>
				<?php
				}
			else
			{
				?>
				<div class="header-links pull-right">
					<?php
					//print_r($_SESSION);
					?>
					<a href=# style="color:white">	Hi, <?php echo $this->session->userdata('name') ?></a>
					<a href="<?php echo base_url() ?>web/donhang" style="color:white">	Don hang</a>
					&nbsp;&nbsp;&nbsp;&nbsp;
						<a href="<?php echo base_url()?>login/logout" style="color:white" onclick="return confirm('Bạn có chắc chắn Đăng xuất không ?')">Đăng xuất</a>
				</div>
				<?php
			}
				?>
			</div>
			<!-- /TOP HEADER -->

			<!-- MAIN HEADER -->
			<div id="header">
				<!-- container -->
				<div class="container">
					<!-- row -->
					<div class="row">
						<!-- LOGO -->
						<div class="col-md-3">
							<div class="header-logo">
								<a href="<?php echo base_url(); ?>web/index" class="logo">
									<img src="<?php echo base_url(); ?>
/assets/img/logo.png" alt="">
								</a>
							</div>
						</div>
						<!-- /LOGO -->

						<!-- SEARCH BAR -->
						<div class="col-md-6">
                  		<form method="post" action="<?php echo site_url('web/timkiem');?>">
							<div class="header-search">
								<form>
               
                                
								
									<input class="input" name="timkiem" placeholder="Nhập từ khóa cần tìm">

									<button class="search-btn" name="submit" type="submit" value="" >Search</button>
								</form>
							</div>
                        </form>
						</div>
						<!-- /SEARCH BAR -->

						<!-- ACCOUNT -->
						<div class="col-md-3 clearfix">
							<div class="header-ctn">
								<!-- Wishlist -->
								
								<!-- /Wishlist -->

								<!-- Cart -->
								<div class="dropdown">
									<a class="dropdown-toggle" data-toggle="dropdown" aria-expanded="true">
										<i class="fa fa-shopping-cart"></i>
										<span>Your Cart</span>
										<div class="qty"></div>
									</a>
									<div class="cart-dropdown">
										<div class="cart-list">
											
											<?php 

									$this->load->library('cart');
									foreach ($this->cart->contents() as $key => $value) 
											{
												?>
											<div class="product-widget">

												<div class="product-body">
													<h3 class="product-name"><a href="#"><?php echo $value['name']; ?></a></h3>
													<h4 class="product-price"><span class="qty"  ><?php echo $value['qty']; ?></span><?php echo number_format($value['price']); ?></h4>
												</div>
												<button class="delete"><i class="fa fa-close"></i></button>
											</div>
											<?php
										}
											?>
										</div>
										
										<div class="cart-btns">
											<a href="<?php echo base_url() ?>mycart/show">View Cart</a>
											<a href="<?php echo base_url() ?>Mycart/Checkout">Checkout  <i class="fa fa-arrow-circle-right"></i></a>
										</div>
									</div>
								</div>
								<!-- /Cart -->

								<!-- Menu Toogle -->
								<div class="menu-toggle">
									<a href="#">
										<i class="fa fa-bars"></i>
										<span>Menu</span>
									</a>
								</div>
								<!-- /Menu Toogle -->
							</div>
						</div>
						<!-- /ACCOUNT -->
					</div>
					<!-- row -->
				</div>
				<!-- container -->
			</div>
			<!-- /MAIN HEADER -->
		</header>
		<!-- /HEADER -->

		<!-- NAVIGATION -->
		<nav id="navigation">
			<!-- container -->
			<div class="container">
				<!-- responsive-nav -->
				<div id="responsive-nav">
					<!-- NAV -->
					<ul class="main-nav nav navbar-nav">
						<li class="active"><a href="<?php echo base_url(). 'web/index' ?>">Home</a></li>
									<?php 
						foreach ($data1 as $key => $value) {
												
						?>
									<li class="active"><a data-toggle="tab" href="#">||</a></li>
									<li><a  href="<?php echo base_url().'web/storemuc/'.$value->idloaisp;?>"><?php echo $value->tenloaisp?></a></li>
									
									<?php 
						}?>
					</ul>
					<!-- /NAV -->
				</div>
				<!-- /responsive-nav -->
			</div>
			<!-- /container -->
		</nav>
		<!-- /NAVIGATION -->

		<!-- BREADCRUMB -->
	<div id="breadcrumb" class="section">
			<!-- container -->
			<div class="container">
				<!-- row -->
				<div class="row">
					<div class="col-md-12">
						<ul class="breadcrumb-tree">
							<li><u><a href="#" onclick="window.history.go(-1)">BACK</a></u></li>
							<?php 
							foreach ($menuct as $key => $value) 
							
							{
							?>
							<li><a href="#"><?php echo $value->tenloaisp?></a></li>
							<?php 
							}
							?>
					
						</ul>
					</div>
				</div>
				<!-- /row -->
			</div>
			<!-- /container -->
		</div>
		<!-- /BREADCRUMB -->

		<!-- SECTION -->
		<div class="section">
			<!-- container -->
			<div class="container">
				<!-- row -->
				<div class="row">
					<!-- ASIDE -->
					<div id="aside" class="col-md-3">
						<!-- aside Widget -->
						<div class="aside">
							<h3 class="aside-title"></h3>
							<div class="checkbox-filter">

								

								
							</div>
						</div>
						<!-- /aside Widget -->

						<!-- aside Widget -->
						<div class="aside">
							<h3 class="aside-title"></h3>
							
						</div>
						<!-- /aside Widget -->

						<!-- aside Widget -->
						<div class="aside">
							
						</div>
						<!-- /aside Widget -->

						<!-- aside Widget -->
						<div class="aside">
							
						</div>
						<!-- /aside Widget -->
					</div>
					<!-- /ASIDE -->

					<!-- STORE -->
					<div id="store" class="col-md-9">
						<!-- store top filter -->
						<div class="store-filter clearfix">
							<div class="store-sort">
								<label style="font-size: 24px;">
									SẢN PHẨM Ở DẠNG THƯ MỤC
									
								</label>

								<label>
									
								</label>
							</div>
							<ul class="store-grid">
								<li ><a href="<?php echo base_url().'web/store/'.$value->idloaisp;?>"><i class="fa fa-th"></i></a></li>
								<li class="active"><i class="fa fa-th-list"></i></li>
							</ul>
						</div>
						<!-- /store top filter -->

						<!-- store products -->
						<div class="row">
							<!-- product -->
							
			          <div class="card-header">
			            <i class="fas fa-table"></i>
			            Danh mục </div>
			          <div class="card-body">
			            <div class="table-responsive">
			              <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
			                <thead>
			                  <tr>
			                  <th>Tên Sản Phẩm</th>
			                    <th>Giá</th>
			                    <th>Hình</th>
			                    <th >Mô Tả SP</th>
			                    <th>ID Sản Phẩm</th>
			                    <th>ID Loại</th>		                    
			                    <th >Action</th>
			                  </tr>
			                </thead>
			                <tfoot>
			                  <tr>
			                   <th>Tên Sản Phẩm</th>
			                    <th>Giá</th>
			                    <th>Hình</th>
			                    <th >Mô Tả SP</th>
			                    <th>ID Sản Phẩm</th>
			                    <th>ID Loại</th>
			                    <th >Action</th>
			                  </tr>
			                </tfoot>
			                <tbody>
			                	<?php
			                	//print_r($test);exit;
				                    foreach ($test as $key => $value) 
				                    {
				                    ?>

				                        <tr>
				                    <td><a href="<?php echo base_url() . 'web/chitiet/'.$value['idsp']; ?>">
				                     <?php echo $value['tensp'];?>
				                        
				                      </a></td>
				                    <td>
				                      <?php echo $value['giasp'];?>
				                    </td>
				                    <td>
				                      <img src="<?php echo base_url()?>assets/img/sanpham/<?php echo $value['mausp'] ?>" >
				                    </td>
				                    <td>
				                    	<?php echo $value['motasp'];?>
				                    </td>
				                     <td>
				                    	<?php echo $value['idsp'];?>
				                    </td>
				                    <td>
				                    	<?php echo $value['idloaisp'];?>
				                    </td>
				                     <td>
				                    	<a href="#" onclick="form_<?php echo $value['idsp'];?>.submit();"><i class="fa fa-shopping-cart" style="color: red;">Add to card</a>
				                    </td>
				                    <form action="<?php echo base_url() ?>mycart/add" method="post" accept-charset="utf-8" id='form_<?php echo $value['idsp']; ?>' style="float: right;">
				<input type="hidden" name="idsp" value="<?php echo $value['idsp']; ?>">
				<input type="hidden" name="soluong" value="1">
				<input type="hidden" name="giasp" value="<?php echo $value['giasp']; ?>">
				<input type="hidden" name="tensp" value="<?php echo $value['tensp']; ?>">
			</form>
										</tr>
			          					
			            	<?php }?>
			                </tbody>
			              </table>
			            </div>
			          </div>
			          <div class="card-footer small text-muted">Sản phẩm theo danh mục</div>
			        <style type="text/css">
			          #dataTable img{width: 50px}
			        </style>

							<!-- /product -->

							<!-- product -->
						
							<!-- /product -->

							<div class="clearfix visible-sm visible-xs"></div>

							<!-- product -->
					
							<!-- /product -->

							<div class="clearfix visible-lg visible-md"></div>

							<!-- product -->
							
							<!-- /product -->

							<div class="clearfix visible-sm visible-xs"></div>

							<!-- product -->
					
							<!-- /product -->

							<!-- product -->
							
							<!-- /product -->

							<div class="clearfix visible-lg visible-md visible-sm visible-xs"></div>

							<!-- product -->
							
							<!-- /product -->

							<!-- product -->
					
							<!-- /product -->

							<div class="clearfix visible-sm visible-xs"></div>

							<!-- product -->
						
							<!-- /product -->
						</div>
						<!-- /store products -->

						<!-- store bottom filter -->
						<div class="store-filter clearfix">
							<span class="store-qty">Showing 20-100 products</span>

							<ul class="store-pagination">
								 
							<p style="color:blue;font-size:25px; border: red solid 2px;"><a href=""><?php echo $this->pagination->create_links(); ?></a></p>
							</ul>
						</div>
						<!-- /store bottom filter -->
					</div>
					<!-- /STORE -->
				</div>
				<!-- /row -->
			</div>
			<!-- /container -->
		</div>
		<!-- /SECTION -->

		<!-- NEWSLETTER -->
		<div id="newsletter" class="section">
			<!-- container -->
			<div class="container">
				<!-- row -->
				<div class="row">
					<div class="col-md-12">
						<div class="newsletter">
							<p>Bạn chưa là <strong>Thành Viên ?</strong></p>
							<form>
								<input class="input" type="email" placeholder="Enter Your Email">
								<button ><a href="<?php echo base_url()?>login/index1/">Đăng Ký</button>
							</form>
							<ul class="newsletter-follow">
								<li>
									<a href="#"><i class="fa fa-facebook"></i></a>
								</li>
								<li>
									<a href="#"><i class="fa fa-twitter"></i></a>
								</li>
								<li>
									<a href="#"><i class="fa fa-instagram"></i></a>
								</li>
								<li>
									<a href="#"><i class="fa fa-pinterest"></i></a>
								</li>
							</ul>
						</div>
					</div>
				</div>
				<!-- /row -->
			</div>
			<!-- /container -->
		</div>
		<!-- /NEWSLETTER -->

		<!-- FOOTER -->
		<footer id="footer">
			<!-- top footer -->
			<div class="section">
				<!-- container -->
				<div class="container">
					<!-- row -->
				
						<div class="col-md-3 col-xs-6">
							<div class="footer">
								<h3 class="footer-title">Về Chúng Tôi</h3>
								<p>Trang web bán hàng điện tử công nghệ uy tín nhất tại Việt Nam </p>
								<ul class="footer-links">
									<li><a href="#"><i class="fa fa-map-marker"></i> 80 Cao Lỗ Phường 4 Q8</a></li>
									<li><a href="#"><i class="fa fa-phone"></i>+021-95-51-84</a></li>
									<li><a href="#"><i class="fa fa-envelope-o"></i>email@email.com</a></li>
								</ul>
							</div>
						</div>

						

						<div class="clearfix visible-xs"></div>

						<div class="col-md-3 col-xs-6">
							<div class="footer">	
								<h3 class="footer-title">Thông Tin</h3>
								<ul class="footer-links">
									<li><a href="<?php echo base_url(). 'web/index' ?>">Sản phẩm</a></li>
						<li><a href="<?php echo base_url(). 'web/about' ?>">Về chúng tôi</a></li>
						<li><a href="<?php echo base_url(). 'web/chinhsachbm' ?>">Chính sách bảo mật</a></li>
						<li><a href="<?php echo base_url(). 'web/dieukhoandv' ?>">Điều khoản dịch vụ</a></li>
						<li><a href="<?php echo base_url(). 'web/contact' ?>">Liên hệ</a></li>
								</ul>
							</div>
						</div>

						<div class="col-md-3 col-xs-6">
							<div class="footer">
								<h3 class="footer-title">Sản Phẩm</h3>
								<ul class="footer-links">
									<?php 
						foreach ($data1 as $key => $value) {
												
						?>
									<li class="active"><a data-toggle="tab" href="#"></a></li>
									<li><a  href="<?php echo base_url().'web/storemuc/'.$value->idloaisp;?>"><?php echo $value->tenloaisp?></a></li>
									
									<?php 
						}?>
								</ul>
							</div>
						</div>
					</div>
						<!-- /row -->
				</div>
				<!-- /container -->
			</div>
			<!-- /bottom footer -->
		</footer>
		<!-- /FOOTER -->

		<!-- jQuery Plugins -->
		<script src="<?php echo base_url(); ?>
/assets/js/jquery.min.js"></script>
		<script src="<?php echo base_url(); ?>
/assets/js/bootstrap.min.js"></script>
		<script src="<?php echo base_url(); ?>
/assets/js/slick.min.js"></script>
		<script src="<?php echo base_url(); ?>
/assets/js/nouislider.min.js"></script>
		<script src="<?php echo base_url(); ?>
/assets/js/jquery.zoom.min.js"></script>
		<script src="<?php echo base_url(); ?>
/assets/js/main.js"></script>

	</body>
</html>
