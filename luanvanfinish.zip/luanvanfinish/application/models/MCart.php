<?php
class MCart extends CI_Model
{
	function insertOrder($data)
	{
		$insert =$this->db->insert('dondh', $data);
		if (!$insert ) 
		{
   			echo "rk,". $this->db->last_query();//exit;
   			return 0;
		} else 
		{
  			return 1;
  			//echo "Ok,". $this->db->last_query();//exit;
		}
	}

	function saveOrderDetail($data)
	{
		$insert =$this->db->insert_batch('chitietdh', $data);
		//echo $this->db->last_query();
		if (!$insert ) 
		{
   			return 0;
		} else 
		{
  			return 1;
  			//echo "Ok,". $this->db->last_query();//exit;
		}
	}
}